package com.polstrat.cadre.modelClass.requestModel

data class VerifyOtpRequest(
    var phone: String,
    var otp: String
)
