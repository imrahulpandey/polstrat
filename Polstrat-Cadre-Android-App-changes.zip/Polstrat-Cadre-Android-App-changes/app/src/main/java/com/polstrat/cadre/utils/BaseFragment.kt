package com.polstrat.cadre.utils

import android.content.Context
import android.graphics.Color
import android.widget.Toast
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.fragment.app.Fragment
import com.github.mikephil.charting.animation.Easing
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import com.github.mikephil.charting.utils.MPPointF
import com.google.android.material.bottomappbar.BottomAppBar
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.polstrat.cadre.R
import com.polstrat.cadre.modelClass.responseModel.PieChartValues
import java.util.ArrayList

open class BaseFragment : Fragment() {

    fun setBottomNavVisibility(visibility: Int) {
        val navBar: BottomNavigationView = requireActivity().findViewById(R.id.bottom_nav_view)
        navBar.visibility = visibility

        val appBar: CoordinatorLayout = requireActivity().findViewById(R.id.lyt_parent_bottom_nav)
        appBar.visibility = visibility

        val bottomBar: BottomAppBar = requireActivity().findViewById(R.id.bottomAppBar)
        bottomBar.visibility = visibility

    }

    fun validatePhoneNumber(number: String): Boolean {
        return number.isNotEmpty() && number.length == 10
    }

    fun showToastLong(context: Context, msg: String) {
        Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
    }

    fun showToastShort(context: Context, msg: String) {
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
    }

    fun setPieChart(pieChartData: ArrayList<PieChartValues>, pieChart: PieChart) {
        pieChart.setUsePercentValues(false)
        pieChart.description?.isEnabled = false

        pieChart.setExtraOffsets(5f, 10f, 5f, 5f)

        // on below line we are setting drag for our pie chart
        pieChart.dragDecelerationFrictionCoef = 0.95f

        // on below line we are setting hole
        // and hole color for pie chart
        pieChart.isDrawHoleEnabled = true
        // on below line we are setting circle color and alpha
        pieChart.setTransparentCircleColor(Color.WHITE)
        pieChart.setTransparentCircleAlpha(110)

        // on  below line we are setting hole radius
        pieChart.holeRadius = 65f
        pieChart.transparentCircleRadius = 61f

        // on below line we are setting center text
        pieChart.setDrawCenterText(false)

        // on below line we are setting
        // rotation for our pie chart
        pieChart.rotationAngle = 0f

        // enable rotation of the pieChart by touch
        pieChart.isRotationEnabled = true
        pieChart.isHighlightPerTapEnabled = true

        // on below line we are setting animation for our pie chart
        pieChart.animateY(1400, Easing.EaseInOutQuad)

        // on below line we are disabling our legend for pie chart
        pieChart.legend?.isEnabled = false
        pieChart.setDrawEntryLabels(true)

        // on below line we are creating array list and
        // adding data to it to display in pie chart
        val entries: ArrayList<PieEntry> = ArrayList()
        for (data in pieChartData) {
            entries.add(PieEntry(data.percent!!.toFloat()))
        }

        // on below line we are setting pie data set
        val dataSet = PieDataSet(entries, "Exercise")

        // on below line we are setting icons.
        dataSet.setDrawIcons(false)

        // on below line we are setting slice for pie
        dataSet.sliceSpace = 3f
        dataSet.iconsOffset = MPPointF(0f, 40f)
        dataSet.selectionShift = 5f

        // add a lot of colors to list
        val colors: ArrayList<Int> = ArrayList()
        for (clr in pieChartData) {
            colors.add(Color.parseColor(clr.color))
        }

        // on below line we are setting colors.
        dataSet.colors = colors

        // on below line we are setting pie data set
        val data = PieData(dataSet)
        // data.setValueFormatter(PercentFormatter())
        data.setValueTextSize(0f)
//        data.setValueTypeface(Typeface.DEFAULT_BOLD)
//        data.setValueTextColor(Color.WHITE)
        pieChart.data = data

        // undo all highlights
        pieChart.highlightValues(null)

        // loading chart
        pieChart.invalidate()
    }
}