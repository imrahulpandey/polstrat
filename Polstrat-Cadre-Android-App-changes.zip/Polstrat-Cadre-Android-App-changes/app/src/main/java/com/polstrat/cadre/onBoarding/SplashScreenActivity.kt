package com.polstrat.cadre.onBoarding

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.databinding.DataBindingUtil
import com.move.radianandroid.utils.datastore.DataStoreManager
import com.polstrat.cadre.R
import com.polstrat.cadre.databinding.ActivitySplashScreenBinding
import com.polstrat.cadre.fragment.HostActivity
import com.polstrat.cadre.utils.BaseActivity
import com.polstrat.cadre.utils.Spec
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

class SplashScreenActivity : BaseActivity(), Spec {

    private lateinit var binding: ActivitySplashScreenBinding
    private var clientId = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        window.statusBarColor = resources.getColor(R.color.button_color)
        window.navigationBarColor = resources.getColor(R.color.button_color)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_splash_screen)
        setUpResources()
    }

    override fun setUpResources() {
        val splashVideo = "android.resource://" + packageName + "/" + R.raw.polstrat_animated_logo
        binding.splashVideo.setVideoURI(Uri.parse(splashVideo))
        binding.splashVideo.start()
        binding.splashVideo.setOnCompletionListener {
            runBlocking {
                launch {
                    clientId = DataStoreManager(this@SplashScreenActivity).getClientId()
                    if (clientId.isNotEmpty()) {
                        startActivity(Intent(this@SplashScreenActivity, HostActivity::class.java))
                    } else {
                        startActivity(
                            Intent(
                                this@SplashScreenActivity,
                                OnBoardHostActivity::class.java
                            )
                        )
                    }
                    finish()
                }
            }
        }
    }

    override fun shutDown() {
        TODO("Not yet implemented")
    }


}