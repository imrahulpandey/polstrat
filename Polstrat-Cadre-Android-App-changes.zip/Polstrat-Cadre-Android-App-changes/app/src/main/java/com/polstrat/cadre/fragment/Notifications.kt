package com.polstrat.cadre.fragment

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.paging.LoadState
import com.move.radianandroid.utils.datastore.DataStoreManager
import com.polstrat.cadre.R
import com.polstrat.cadre.adapterClass.NotificationListAdapter
import com.polstrat.cadre.adapterClass.PaginationLoaderAdapter
import com.polstrat.cadre.databinding.FragmentNotificationsBinding
import com.polstrat.cadre.modelClass.responseModel.NotificationMarkedReadResponse
import com.polstrat.cadre.networkClient.NetworkResult
import com.polstrat.cadre.utils.BaseFragment
import com.polstrat.cadre.utils.Spec
import com.polstrat.cadre.viewModels.MainViewModel
import com.polstrat.cadre.viewModels.NotificationViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.FlowCollector
import kotlinx.coroutines.launch

class Notifications : BaseFragment(), Spec {

    lateinit var binding: FragmentNotificationsBinding
    private val notificationViewModel: NotificationViewModel by activityViewModels()
    private val mainViewModel: MainViewModel by activityViewModels()
    private lateinit var notificationListAdapter: NotificationListAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding =
            DataBindingUtil.inflate(inflater, R.layout.fragment_notifications, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.apply {
            presenter = this@Notifications
            lifecycleOwner = this@Notifications
            executePendingBindings()
        }
        setUpResources()
    }

    override fun setUpResources() {
        setBottomNavVisibility(View.GONE)
        mainViewModel.redirectToNotif.postValue("")
        notificationListAdapter = NotificationListAdapter(this@Notifications)
        CoroutineScope(Dispatchers.Default).launch {
            DataStoreManager(requireContext()).saveNotificationReceived("false")
        }
        mainViewModel.isNotificationReceived.value = "false"
        getAllNotifications()
    }

    private fun getAllNotifications() {
        viewLifecycleOwner.lifecycleScope.launchWhenCreated {
            notificationViewModel.getNotificationsList(
                "Bearer ${DataStoreManager(requireContext()).getCadreToken()}"
            ).collect { pagingData ->
                binding.rvNotifList.adapter = notificationListAdapter.withLoadStateHeaderAndFooter(
                    header = PaginationLoaderAdapter(),
                    footer = PaginationLoaderAdapter()
                )
                notificationListAdapter.submitData(pagingData)
            }
        }
        notificationListAdapter.addLoadStateListener { loadState ->
            val isEmpty =
                loadState.refresh is LoadState.NotLoading && notificationListAdapter.itemCount == 0
            if (isEmpty) {
                // Show empty text
                binding.emptyData.visibility = View.VISIBLE
                binding.rvNotifList.visibility = View.GONE
            } else {
                // Show RecyclerView
                binding.emptyData.visibility = View.GONE
                binding.rvNotifList.visibility = View.VISIBLE
            }

            val isLoading = loadState.refresh is LoadState.Loading
            if (isLoading) {
                binding.loader.visibility = View.VISIBLE
                binding.loader.startAnimation(
                    AnimationUtils.loadAnimation(
                        requireContext(),
                        R.anim.loader_animation
                    )
                )
            } else {
                binding.loader.clearAnimation()
                binding.loader.visibility = View.GONE
            }
        }
    }

    fun markAsRead() {
        lifecycleScope.launchWhenStarted {
            notificationViewModel.markAsReadAll(
                "Bearer ${DataStoreManager(requireContext()).getCadreToken()}"
            ).collect(statsCollector)
        }
    }

    private val statsCollector: FlowCollector<NetworkResult<NotificationMarkedReadResponse>> =
        FlowCollector { response ->
            when (response) {
                is NetworkResult.Loading -> {

                }

                is NetworkResult.Success -> {
                    response.data?.let {
                        Log.d(TAG, "$it")
                        Toast.makeText(
                            context,
                            "${it.data.modifiedCount} data modified!",
                            Toast.LENGTH_SHORT
                        ).show()
                        getAllNotifications()
                    }
                }

                is NetworkResult.Error -> {
                    Log.e(TAG, "response error ${response.message}")
                }
            }
        }

    fun goBack() {
        requireActivity().onBackPressedDispatcher.onBackPressed()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        shutDown()
    }

    override fun shutDown() {
        //doSomething
    }

    companion object {
        const val TAG = "Notification"
    }

}