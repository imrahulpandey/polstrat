package com.polstrat.cadre.adapterClass

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.appcompat.content.res.AppCompatResources
import androidx.databinding.DataBindingUtil
import androidx.paging.PagingDataAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.move.radianandroid.utils.datastore.DataStoreManager
import com.polstrat.cadre.PolstratAndroidApplication
import com.polstrat.cadre.R
import com.polstrat.cadre.databinding.NotificationItemsBinding
import com.polstrat.cadre.diffUtils.NotificationDiffUtilClass
import com.polstrat.cadre.fragment.Notifications
import com.polstrat.cadre.modelClass.responseModel.NotificationList
import com.polstrat.cadre.utils.Constants
import com.polstrat.cadre.utils.Constants.convertDateFormat
import com.polstrat.cadre.utils.Constants.getTimeInCustomFormat

class NotificationListAdapter(val presenterFrag: Notifications) :
    PagingDataAdapter<NotificationList, NotificationListAdapter.ViewHolder>(
        NotificationDiffUtilClass()
    ) {
    private var context = PolstratAndroidApplication.appContext

    inner class ViewHolder(val binding: NotificationItemsBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(notificationList: NotificationList) {
            binding.apply {
                presenter = presenterFrag

                when (notificationList.isViewed) {
                    true -> {
                        lytMain.background = AppCompatResources.getDrawable(
                            context,
                            R.drawable.gray_border_background
                        )
                    }

                    false -> {
                        lytMain.background = AppCompatResources.getDrawable(
                            context,
                            R.drawable.light_blue_border_background
                        )
                    }
                }

                Glide.with(context)
                    .load(notificationList.profileURL)
                    .diskCacheStrategy(
                        DiskCacheStrategy.RESOURCE
                    )
                    .into(binding.notifImage)
                tvContent.text = notificationList.content
                tvDate.text = "${convertDateFormat(notificationList.createdAt)} at ${
                    getTimeInCustomFormat(notificationList.createdAt)
                }"
            }

        }

    }

    override fun onBindViewHolder(holder: NotificationListAdapter.ViewHolder, position: Int) {
        getItem(position)?.let { holder.bind(it) }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): NotificationListAdapter.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding: NotificationItemsBinding =
            DataBindingUtil.inflate(inflater, R.layout.notification_items, parent, false)
        return ViewHolder(binding)
    }
}