package com.polstrat.cadre.modelClass.responseModel

data class ViewPagerModel(
    val illustrator: Int,
    val title: String,
    val description: String
)
