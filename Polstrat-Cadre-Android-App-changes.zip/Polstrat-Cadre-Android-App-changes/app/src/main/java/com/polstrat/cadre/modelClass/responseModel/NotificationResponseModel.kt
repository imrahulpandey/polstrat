package com.polstrat.cadre.modelClass.responseModel

import com.google.gson.annotations.SerializedName

data class NotificationResponseModel(
    val error: Any,
    val message: MessageData,
    val status: Boolean
)

data class MessageData(
    val currentpage: Int,
    val data: List<NotificationList>,
    val error: Any,
    val message: String,
    val notificationCount: Int,
    val status: Boolean,
    val totalpages: Int
)

data class NotificationList(
    @SerializedName("__v")
    val v: Int? = null,
    @SerializedName("_id")
    val id: String? = null,
    val collectionName: String,
    val content: String,
    val createdAt: String,
    val creator: String,
    val creatorType: String,
    val documentId: String,
    val isViewed: Boolean,
    val profileURL: String? = null,
    val `receiver`: String,
    val receiverType: String,
    val status: String,
    val title: String,
    val updatedAt: String
)