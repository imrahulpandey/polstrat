package com.polstrat.cadre.fragment

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.AdapterView
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import com.move.radianandroid.utils.datastore.DataStoreManager
import com.polstrat.cadre.CustomSpinnerAdapter
import com.polstrat.cadre.R
import com.polstrat.cadre.databinding.FragmentReportAnIssueBinding
import com.polstrat.cadre.modelClass.requestModel.IssueReportRequest
import com.polstrat.cadre.modelClass.responseModel.ReportedIssueModelResponse
import com.polstrat.cadre.networkClient.NetworkResult
import com.polstrat.cadre.utils.BaseFragment
import com.polstrat.cadre.utils.Constants
import com.polstrat.cadre.utils.Constants.getCurrentDate
import com.polstrat.cadre.utils.LoaderDialog
import com.polstrat.cadre.utils.Spec
import com.polstrat.cadre.viewModels.FormViewModel
import kotlinx.coroutines.flow.FlowCollector

class ReportAnIssue : BaseFragment(), Spec {

    lateinit var binding: FragmentReportAnIssueBinding
    private val formViewModel: FormViewModel by activityViewModels()
    private var categoryName = ""
    private lateinit var loaderDialog: LoaderDialog

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding =
            DataBindingUtil.inflate(inflater, R.layout.fragment_report_an_issue, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.apply {
            presenter = this@ReportAnIssue
            lifecycleOwner = this@ReportAnIssue
            executePendingBindings()
        }
        setUpResources()
    }

    fun goBack() {
        requireActivity().onBackPressedDispatcher.onBackPressed()
    }

    fun cancelIssue() {
        goBack()
    }

    fun submitIssue() {
        lifecycleScope.launchWhenResumed {
            if (validationForm()) {
                val issueReportRequest = IssueReportRequest(
                    categoryName,
                    binding.edtDes.text.toString(),
                    getCurrentDate(),
                    DataStoreManager(requireContext()).getEmail(),
                    binding.edtIssue.text.toString(),
                    DataStoreManager(requireContext()).getFName(),
                    binding.edtMobNum.text.toString().toLong()
                )
                Log.d(TAG, "issueReportRequest, $issueReportRequest")
                formViewModel.raiseTickets(
                    issueReportRequest,
                    "Bearer ${DataStoreManager(requireContext()).getCadreToken()}",

                    ).collect(issueStatsCollector)

            }
        }
    }

    private fun validationForm(): Boolean {
        if (binding.edtIssue.text.toString().isEmpty()) {
            binding.edtIssue.error = ""
            showToastShort(requireContext(), "Please enter issue!")
        } else if (binding.edtDes.text.toString().isEmpty()) {
            binding.edtDes.error = ""
            showToastShort(requireContext(), "Please enter description!")
        } else if (binding.edtMobNum.text.toString()
                .isEmpty() || binding.edtMobNum.text.toString().length != 10
        ) {
            binding.edtMobNum.error = ""
            showToastShort(requireContext(), "Invalid phone number!")
        } else {
            return true
        }
        return false
    }

    override fun setUpResources() {
        setBottomNavVisibility(View.GONE)
        populateGenderSpinner()
        loaderDialog = LoaderDialog(requireContext())
        binding.edtMobNum.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                //write your login
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                //write your login
            }

            override fun afterTextChanged(s: Editable?) {
                // Check if the input length reaches 10 digits
                if (s?.length == 10) {
                    // If 10 digits entered, hide the keyboard
                    Constants.hideKeyboard(requireContext(), binding.edtMobNum)
                }
            }
        })
    }


    private fun populateGenderSpinner() {
        val items = listOf("Please select", "GMS", "TMS", "Others")
        val adapter =
            CustomSpinnerAdapter(requireContext(), R.layout.spinner_items, items)

        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

        // Apply the adapter to the spinner
        binding.spnCate.adapter = adapter

        // Set an item selected listener for the spinner
        binding.spnCate.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: android.view.View?,
                position: Int,
                id: Long
            ) {
                if (position != 0) {
                    // Handle the selected item
                    val selectedItem = items[position]
                    // You can perform actions based on the selected item here
                    categoryName = selectedItem
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                // Handle when nothing is selected (optional)
            }
        }
    }


    private val issueStatsCollector: FlowCollector<NetworkResult<ReportedIssueModelResponse>> =
        FlowCollector { response ->
            when (response) {
                is NetworkResult.Loading -> {
                    loaderDialog.show()
                }

                is NetworkResult.Success -> {
                    response.data?.let {
                        Log.d(TAG, "$it")
                        it.data.let { dataList ->
                            loaderDialog.dismiss()
                            showToastShort(requireContext(), it.message)
                            clearFields()
                        }

                    }
                }

                is NetworkResult.Error -> {
                    Log.e(TAG, "response error ${response.message}")
                    loaderDialog.dismiss()
                    showToastShort(requireContext(), response.message)
                }
            }
        }

    companion object {
        const val TAG = "ReportAnIssue"
    }

    override fun onDestroyView() {
        super.onDestroyView()
        shutDown()
    }

    private fun clearFields() {
        categoryName = ""
        binding.edtDes.text?.clear()
        binding.edtIssue.text?.clear()
        binding.edtMobNum.text?.clear()
        goBack()
    }

    override fun shutDown() {
        //do Something
    }
}