package com.polstrat.cadre.fragment

import android.Manifest
import android.app.Activity.RESULT_OK
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ImageView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.content.res.AppCompatResources
import androidx.appcompat.widget.AppCompatImageView
import androidx.appcompat.widget.LinearLayoutCompat
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.move.radianandroid.utils.datastore.DataStoreManager
import com.polstrat.cadre.CustomDialog
import com.polstrat.cadre.CustomSpinnerAdapter
import com.polstrat.cadre.PolstratAndroidApplication
import com.polstrat.cadre.R
import com.polstrat.cadre.databinding.FragmentFormBinding
import com.polstrat.cadre.databinding.LytNewCameraGalleryPickerDialogBinding
import com.polstrat.cadre.modelClass.Categories
import com.polstrat.cadre.modelClass.Data
import com.polstrat.cadre.modelClass.requestModel.FormRequestModel
import com.polstrat.cadre.modelClass.requestModel.Location
import com.polstrat.cadre.modelClass.requestModel.UploadImage
import com.polstrat.cadre.modelClass.responseModel.FormResponseModel
import com.polstrat.cadre.modelClass.responseModel.GetImageData
import com.polstrat.cadre.networkClient.APIInterface
import com.polstrat.cadre.networkClient.NetworkResult
import com.polstrat.cadre.networkClient.ServiceBuilder
import com.polstrat.cadre.utils.BaseFragment
import com.polstrat.cadre.utils.Constants.dpToPx
import com.polstrat.cadre.utils.Constants.getFileExtension
import com.polstrat.cadre.utils.Constants.getMimeType
import com.polstrat.cadre.utils.Constants.hideKeyboard
import com.polstrat.cadre.utils.LoaderDialog
import com.polstrat.cadre.utils.Spec
import com.polstrat.cadre.viewModels.FormViewModel
import com.polstrat.cadre.viewModels.MainViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.FlowCollector
import kotlinx.coroutines.launch
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


class FormFragment : BaseFragment(), Spec {

    lateinit var binding: FragmentFormBinding
    private val formViewModel: FormViewModel by activityViewModels()
    private val mainViewModel: MainViewModel by activityViewModels()
    private var visitorType = ""
    private var categoryId = ""
    private var categoryName = ""
    private var subCategoryId = ""
    private var subCategoryName = ""
    private var gender = ""
    private var lat = ""
    private var title = "No Title"
    private var longi = ""
    private var addr = ""
    private var currentPhotoPath: String? = null
    private var currentPhotoName: String? = null
    private lateinit var loaderDialog: LoaderDialog


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = DataBindingUtil.inflate(layoutInflater, R.layout.fragment_form, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.apply {
            presenter = this@FormFragment
            lifecycleOwner = this@FormFragment
            executePendingBindings()
        }
        setUpResources()

        mainViewModel.redirectToNotif.observe(viewLifecycleOwner) {
            if (it.equals("true")) {
                openNotification()
            }
        }

        CoroutineScope(Dispatchers.Default).launch {
            if (DataStoreManager(requireContext()).getNotificationReceived() == "true") {
                binding.imgNotif.setImageResource(R.drawable.unread_notification_ic)
            }else{
                binding.imgNotif.setImageResource(R.drawable.read_notification_ic)
            }
        }
        mainViewModel.isNotificationReceived.observe(viewLifecycleOwner) {
            if (it.equals("true")) {
                binding.imgNotif.setImageResource(R.drawable.unread_notification_ic)
            } else {
                binding.imgNotif.setImageResource(R.drawable.read_notification_ic)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        formViewModel.addr.observe(viewLifecycleOwner) {
            addr = it
        }
        formViewModel.lat.observe(viewLifecycleOwner) {
            lat = it
        }
        formViewModel.lon.observe(viewLifecycleOwner) {
            longi = it
        }

        Log.d(TAG, "LocationData>> addr $addr\n lat $lat\n longi $longi")

    }

    fun goToImageUpload() {
        showPickerDialog()
    }

    private val requestCameraPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { grantResults ->
        if (grantResults) {
            setProfilePicFromCamera()
        } else {
            showToastShort(requireContext(), "Go to setting and allow permission")
        }

    }

    private val requestGalleryPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { grantResults ->
        if (grantResults) {
            setProfilePicFromGallery()
        } else {
            showToastShort(requireContext(), "Go to setting and allow permission")
        }

    }

    override fun setUpResources() {
        setBottomNavVisibility(View.VISIBLE)

        loaderDialog = LoaderDialog(requireContext())
        populateVisitorTypeSpinner()
        populateGenderSpinner()
        lifecycleScope.launchWhenResumed {
            formViewModel.getCategories(
                "Bearer ${DataStoreManager(requireContext()).getCadreToken()}"
            ).collect(categoryStatsCollector)
        }

        if (formViewModel.priority.isNotEmpty()) {
            when (formViewModel.priority) {
                "high" -> {
                    highIssue()
                }

                "medium" -> {
                    mediumIssue()
                }

                else -> {
                    lowIssue()
                }
            }
        }

        formViewModel.imageUrl.forEach { imageUri ->
            createDynamicImageView(imageUri.publicUrl)
        }

        binding.edtMobNum.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                //write your login
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                //write your login
            }

            override fun afterTextChanged(s: Editable?) {
                // Check if the input length reaches 10 digits
                if (s?.length == 10) {
                    // If 10 digits entered, hide the keyboard
                    hideKeyboard(requireContext(), binding.edtMobNum)
                }
            }
        })
    }

    private fun createDynamicImageView(imgUri: String) {
        val imageView = AppCompatImageView(requireContext())

        // Set the image resource programmatically
        Glide.with(requireContext())
            .load(imgUri)
            .diskCacheStrategy(
                DiskCacheStrategy.RESOURCE
            )
            .into(imageView)

        // Set other attributes if needed
        val params = LinearLayoutCompat.LayoutParams(
            dpToPx(resources, 69), dpToPx(resources, 69)
        )

        params.setMargins(
            dpToPx(resources, 5), dpToPx(resources, 5), dpToPx(resources, 5), 0
        )
        imageView.elevation = 5F
        imageView.scaleType = ImageView.ScaleType.FIT_XY
        imageView.layoutParams = params

        imageView.setOnClickListener {
            val zoomDial = CustomDialog(requireContext(), imgUri)
            zoomDial.show()
        }
        // Add ImageView to the layout
        binding.llPhotos.addView(imageView)
    }


    override fun shutDown() {
        //doSomething
    }

    fun openNotification() {
        if (isAdded && findNavController().currentDestination?.label == getString(R.string.form_fragment_label)) {
            lifecycleScope.launchWhenResumed {
                findNavController().navigate(R.id.action_formFragment_to_notificationFragment)
            }
        }
    }

    fun highIssue() {
        formViewModel.priority = "high"
        binding.apply {
            btnHigh.foreground =
                AppCompatResources.getDrawable(
                    requireContext(),
                    R.drawable.selected_priority_background
                )
            btnMedium.foreground = null
            btnLow.foreground = null
        }
    }

    fun mediumIssue() {
        formViewModel.priority = "medium"
        binding.apply {
            btnHigh.foreground = null
            btnMedium.foreground =
                AppCompatResources.getDrawable(
                    requireContext(),
                    R.drawable.selected_priority_background
                )
            btnLow.foreground = null
        }
    }

    fun lowIssue() {
        formViewModel.priority = "low"
        binding.apply {
            btnHigh.foreground = null
            btnMedium.foreground = null
            btnLow.foreground =
                AppCompatResources.getDrawable(
                    requireContext(),
                    R.drawable.selected_priority_background
                )
        }
    }

    fun submitForm() {
        createForm()
    }

    fun addLocation() {
        checkAndAskLocationPermission()
    }

    private val subCategoryStatsCollector: FlowCollector<NetworkResult<Categories>> =
        FlowCollector { response ->
            when (response) {
                is NetworkResult.Loading -> {

                }

                is NetworkResult.Success -> {
                    response.data?.let {
                        Log.d(TAG, "$it")
                        populateSubCategorySpinner(it.data)
                    }
                }

                is NetworkResult.Error -> {
                    Log.e(TAG, "response error ${response.message}")
                }
            }
        }

    private val categoryStatsCollector: FlowCollector<NetworkResult<Categories>> =
        FlowCollector { response ->
            when (response) {
                is NetworkResult.Loading -> {

                }

                is NetworkResult.Success -> {
                    response.data?.let {
                        Log.d(TAG, "$it")
                        populateCategorySpinner(it.data)
                    }
                }

                is NetworkResult.Error -> {
                    Log.e(TAG, "response error ${response.message}")
                }
            }
        }

    private fun populateCategorySpinner(spinnerData: List<Data>) {
        val mutableSpinnerData = spinnerData.toMutableList()

        // Create the new Data object to add
        val disabledElement = Data("0", "", "", "Please select", emptyList())

        // Add element to the 0th index
        mutableSpinnerData.add(0, disabledElement)
        val spinnerAdapter = CustomSpinnerAdapter(requireContext(),
            R.layout.spinner_items,
            mutableSpinnerData.map { it.name })
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spnCat.adapter = spinnerAdapter

        binding.spnCat.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long
            ) {
                if (position != 0) {
                    val selectedItem = mutableSpinnerData[position]
                    categoryId = selectedItem.id
                    categoryName = selectedItem.name
                    lifecycleScope.launchWhenResumed {
                        formViewModel.getSubCategories(
                            selectedItem.id,
                            "Bearer ${DataStoreManager(requireContext()).getCadreToken()}"
                        ).collect(subCategoryStatsCollector)
                    }
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                // Do nothing here
            }
        }
    }

    private fun populateSubCategorySpinner(spinnerData: List<Data>) {
        val mutableSpinnerData = spinnerData.toMutableList()

        // Create the new Data object to add
        val disabledElement = Data("0", "", "", "Please select", emptyList())

        // Add element to the 0th index
        mutableSpinnerData.add(0, disabledElement)
        val spinnerAdapter = CustomSpinnerAdapter(requireContext(),
            R.layout.spinner_items,
            mutableSpinnerData.map { it.name })

        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spnSubCat.adapter = spinnerAdapter

        binding.spnSubCat.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long
            ) {
                if (position != 0) {
                    val selectedItem = mutableSpinnerData[position]
                    subCategoryId = selectedItem.id
                    subCategoryName = selectedItem.name
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                // Do nothing here
            }
        }
    }

    private fun populateVisitorTypeSpinner() {
        val items = listOf("Select type", "Citizen", "Vip", "Cadre", "Other")
        val adapter =
            CustomSpinnerAdapter(requireContext(), R.layout.spinner_items, items)

        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

        // Apply the adapter to the spinner
        binding.spnType.adapter = adapter

        // Set an item selected listener for the spinner
        binding.spnType.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long
            ) {
                if (position != 0) {
                    // Handle the selected item
                    val selectedItem = items[position]
                    // You can perform actions based on the selected item here
                    visitorType = selectedItem
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                // Handle when nothing is selected (optional)
            }
        }
    }

    private fun populateGenderSpinner() {
        val items = listOf("Select gender", "Male", "Female", "Other")
        val adapter =
            CustomSpinnerAdapter(requireContext(), R.layout.spinner_items, items)

        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

        // Apply the adapter to the spinner
        binding.spnGender.adapter = adapter

        // Set an item selected listener for the spinner
        binding.spnGender.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long
            ) {
                // Handle the selected item
                if (position != 0) {
                    val selectedItem = items[position]
                    // You can perform actions based on the selected item here
                    gender = selectedItem
                }

            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                // Handle when nothing is selected (optional)
            }
        }
    }

    private fun formValidation(): Boolean {
        if (binding.edtFName.text.toString().isEmpty()) {
            binding.edtFName.error = "First name can not be empty!"
            showToastShort(requireContext(), "First name can not be empty!")
        } else if (binding.edtMobNum.text.toString()
                .isEmpty() || binding.edtMobNum.text.toString().length != 10
        ) {
            binding.edtMobNum.error = "Enter valid phone number!"
            showToastShort(requireContext(), "Enter valid phone number!")
        } else if (subCategoryName.isEmpty()) {
            showToastShort(requireContext(), "Select subcategory!")
        } else if (formViewModel.priority.isEmpty()) {
            showToastShort(requireContext(), "Choose priority!")
        } else if (binding.edtDes.text.toString().isEmpty()) {
            binding.edtDes.error = "Description required!"
            showToastShort(requireContext(), "Description required!")
        } else if (addr.isEmpty() || longi.isEmpty() || lat.isEmpty()) {
            showToastShort(requireContext(), "Please mark the location!")
        } else {
            return true
        }
        return false
    }

    private fun createForm() {
        if (binding.edtIssue.text.toString().isNotEmpty()) {
            title = binding.edtIssue.text.toString()
        }
        lifecycleScope.launchWhenResumed {
            if (formValidation()) {
                val formResponseModel = FormRequestModel(
                    title,
                    categoryId,
                    categoryName,
                    DataStoreManager(requireContext()).getConstituencyId(),
                    binding.edtDes.text.toString(),
                    binding.edtFName.text.toString(),
                    gender,
                    binding.edtLName.text.toString(),
                    Location(addr, lat, longi),
                    binding.edtPeople.text.toString(),
                    binding.edtEmail.text.toString(),
                    binding.edtMobNum.text.toString(),
                    formViewModel.priority,
                    subCategoryId,
                    subCategoryName,
                    formViewModel.imageUrl,
                    visitorType
                )
                Log.d(
                    TAG, "location $formResponseModel"
                )
                formViewModel.createForm(
                    formResponseModel,
                    "Bearer ${DataStoreManager(requireContext()).getCadreToken()}"
                ).collect(createdFormStatsCollector)
            }
        }
    }

    private val createdFormStatsCollector: FlowCollector<NetworkResult<FormResponseModel>> =
        FlowCollector { response ->
            when (response) {
                is NetworkResult.Loading -> {
                    loaderDialog.show()
                }

                is NetworkResult.Success -> {
                    response.data?.let {
                        Log.d(TAG, "$it")
                        loaderDialog.dismiss()
                        clearForm()
                        requireActivity().onBackPressedDispatcher.onBackPressed()
                        showToastLong(requireContext(), it.message)
                    }
                }

                is NetworkResult.Error -> {
                    Log.e(TAG, "response error ${response.message}")
                    loaderDialog.dismiss()
                    showToastLong(requireContext(), response.message)
                }
            }
        }


    private fun checkAndAskLocationPermission() {
        // Check if the required permissions are granted
        if (checkLocationPermission()) {
            // Permissions are already granted, proceed with your logic
            // e.g., initialize the map
            // initializeMap()
            if (isAdded && findNavController().currentDestination?.label == getString(R.string.form_fragment_label)) {
//                findNavController().navigate(R.id.action_formFragment_to_mapFragment)
                findNavController().navigate(R.id.action_formFragment_to_revisedMapFragment)
            }
        } else {
            // Permissions are not granted, request them
            requestLocationPermission()
        }
    }

    private fun checkLocationPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            requireContext(), Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestLocationPermission() {
        ActivityCompat.requestPermissions(
            requireActivity(),
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
            LOCATION_PERMISSION_REQUEST_CODE
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        when (requestCode) {
            LOCATION_PERMISSION_REQUEST_CODE -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // Permission granted, proceed with your logic
                    if (isAdded && findNavController().currentDestination?.label == getString(R.string.form_fragment_label)) {
                        // findNavController().navigate(R.id.action_formFragment_to_mapFragment)
                        findNavController().navigate(R.id.action_formFragment_to_revisedMapFragment)
                    }
                } else {
                    showToastLong(requireContext(), "Please allow the location permission")
                    // Permission denied, handle accordingly (e.g., show a message)
                    // You may also check 'shouldShowRequestPermissionRationale' and explain why you need the permission
                }
            }
        }
    }

    private fun setProfilePicFromGallery() {
        galleryContract.launch("image/*")
    }

    private val galleryContract =
        registerForActivityResult(ActivityResultContracts.GetMultipleContents()) {
            if (it != null) {
                createMultipleFile(it)
            }
        }

    private fun showPickerDialog() {
        val dialog = BottomSheetDialog(requireContext(), R.style.AppBottomSheetDialogTheme)
        val binding: LytNewCameraGalleryPickerDialogBinding = DataBindingUtil.inflate(
            layoutInflater, R.layout.lyt_new_camera_gallery_picker_dialog, null, true
        )

        binding.btnCamera.setOnClickListener {
            dialog.dismiss()
            if (checkCameraPermission()) {
                lifecycleScope.launchWhenResumed {
                    setProfilePicFromCamera()
                }
            } else {
                requestCameraPermission.launch(Manifest.permission.CAMERA)
            }

        }
        binding.btnGallery.setOnClickListener {
            dialog.dismiss()
            if (checkGalleryPermission()) {
                lifecycleScope.launchWhenResumed {
                    setProfilePicFromGallery()
                }
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    requestGalleryPermission.launch(Manifest.permission.READ_MEDIA_IMAGES)
                } else {
                    requestGalleryPermission.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                }
            }
        }
        binding.btnCancel.setOnClickListener {
            dialog.dismiss()
        }

        dialog.setContentView(binding.root)
        dialog.show()
    }

    private fun setProfilePicFromCamera() {
        Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
            takePictureIntent.resolveActivity(PolstratAndroidApplication.appContext.packageManager)
                ?.also {
                    // Create the File where the photo should go
                    val photoFile: File? = try {
                        createImageFile()
                    } catch (ex: IOException) {
                        // Error occurred while creating the File
                        null
                    }
                    // Continue only if the File was successfully created
                    photoFile?.also {
                        val photoURI: Uri = FileProvider.getUriForFile(
                            requireContext(),
                            "com.polstrat.cadre.provider",
                            it
                        )
                        takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                        takePicture.launch(takePictureIntent)
                    }
                }
        }
    }

    private val takePicture =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                if (!currentPhotoName.isNullOrEmpty() && !currentPhotoPath.isNullOrEmpty()) {
                    val imageParts = mutableListOf<MultipartBody.Part>()
                    val file = currentPhotoPath?.let { File(it) }
                    if (file?.exists() == true) {
                        println("${currentPhotoName},$currentPhotoPath")
                        Log.d(TAG, "imageUri: ${Uri.parse(currentPhotoPath)}")

                        val requestBody = file.let {
                            RequestBody.create(
                                MediaType.parse("image"), it
                            )
                        }
                        val part = requestBody.let {
                            MultipartBody.Part.createFormData(
                                "grievanceImages",
                                currentPhotoName,
                                it
                            )
                        }
                        imageParts.add(part)
                        uploadMultipleImages(imageParts)
                    } else {
                        //file not found please select another file.
                        showToastShort(requireContext(), "File not found")
                    }
                }
            }
        }

    private fun createImageFile(): File {
        // Create an image file name
        val timeStamp: String = SimpleDateFormat(FILENAME).format(Date())
        val storageDir: File? =
            PolstratAndroidApplication.appContext.getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile(
            timeStamp, /* prefix */
            ".jpg", /* suffix */
            storageDir /* directory */
        ).apply {
            // Save a file: path for use with ACTION_VIEW intents
            currentPhotoName = this.name
            currentPhotoPath = absolutePath
        }
    }

    private fun checkGalleryPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            PackageManager.PERMISSION_GRANTED == ActivityCompat.checkSelfPermission(
                PolstratAndroidApplication.appContext, Manifest.permission.READ_MEDIA_IMAGES
            )
        } else {
            PackageManager.PERMISSION_GRANTED == ActivityCompat.checkSelfPermission(
                PolstratAndroidApplication.appContext, Manifest.permission.READ_EXTERNAL_STORAGE
            )
        }
    }


    private fun checkCameraPermission(): Boolean {
        return PackageManager.PERMISSION_GRANTED == ActivityCompat.checkSelfPermission(
            PolstratAndroidApplication.appContext, Manifest.permission.CAMERA
        )
    }

    private fun createMultipleFile(uri: List<Uri>) {
        val imageParts = mutableListOf<MultipartBody.Part>()
        for (imageUri in uri) {
            val file = getOutputDirectory()
            val inputStream = requireContext().contentResolver.openInputStream(imageUri)
            val filePath =
                createFile(file, FILENAME, ".${getFileExtension(requireContext(), imageUri)}")
            val outputStream = FileOutputStream(filePath)
            inputStream?.copyTo(outputStream)
            Log.d(TAG, "fileName: $imageUri")
            Log.d(
                TAG, "Selected MIME type: ${getMimeType(requireContext(), imageUri)}\n Extension: ${
                    getFileExtension(requireContext(), imageUri)
                }"
            )

            val request = RequestBody.create(
                MediaType.parse(getMimeType(requireContext(), imageUri).toString()),
                filePath.absoluteFile
            )
            val body = request.let {
                MultipartBody.Part.createFormData(
                    "grievanceImages", filePath.name, it
                )
            }
            imageParts.add(body)
        }
        uploadMultipleImages(imageParts)
    }


    private fun uploadMultipleImages(part: List<MultipartBody.Part>) {
        val retrofitInterface: APIInterface = ServiceBuilder.retrofitInstance
        CoroutineScope(Dispatchers.IO).launch {
            val call = retrofitInterface.uploadImages(
                part, "Bearer ${DataStoreManager(requireContext()).getCadreToken()}"
            )

            call.enqueue(object : Callback<GetImageData> {
                override fun onResponse(
                    call: Call<GetImageData?>, response: Response<GetImageData?>
                ) {
                    if (response.isSuccessful) {
                        Log.d(TAG, "response ${response.body()}")
                        for (url in response.body()?.data as ArrayList<UploadImage>) {
                            formViewModel.imageUrl.add(url)
                        }
                        binding.llPhotos.removeAllViews()
                        formViewModel.imageUrl.forEach { imageUri ->
                            createDynamicImageView(imageUri.publicUrl)
                        }
                        response.body()?.let { showToastShort(requireContext(), it.message) }
                    }
                }

                override fun onFailure(call: Call<GetImageData?>, t: Throwable) {
                    Log.i(TAG, t.message.toString())

                }
            })
        }
    }

    private fun getOutputDirectory(): File {
        val mediaDir = requireActivity().externalMediaDirs.firstOrNull()?.let {
            File(it, "image").apply { mkdirs() }
        }
        return if (mediaDir != null && mediaDir.exists()) mediaDir else requireActivity().filesDir
    }

    companion object {
        const val TAG = "FormsFragment"
        const val LOCATION_PERMISSION_REQUEST_CODE = 1001
        private const val FILENAME = "yyyy-MM-dd-HH-mm-ss-SSS"
        fun createFile(baseFolder: File, format: String, extension: String) = File(
            baseFolder,
            SimpleDateFormat(format, Locale.US).format(System.currentTimeMillis()) + extension
        )
    }

    private fun clearForm() {
        binding.apply {
            visitorType = ""
            categoryId = ""
            categoryName = ""
            subCategoryId = ""
            subCategoryName = ""
            gender = ""
            lat = ""
            title = ""
            longi = ""
            addr = ""
            edtPeople.text?.clear()
            edtDes.text?.clear()
            edtIssue.text?.clear()
            edtFName.text?.clear()
            edtLName.text?.clear()
            edtEmail.text?.clear()
            edtMobNum.text?.clear()
            imgAdd.visibility = View.visibility
            imgAdd.setImageURI(null)
            llImage.removeAllViews()
            formViewModel.priority = ""
            formViewModel.imageUrl.clear()
        }
    }
}