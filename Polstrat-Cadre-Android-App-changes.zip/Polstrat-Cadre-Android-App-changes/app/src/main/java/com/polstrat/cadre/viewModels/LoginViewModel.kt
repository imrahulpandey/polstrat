package com.polstrat.cadre.viewModels

import android.app.Application
import com.polstrat.cadre.modelClass.responseModel.UniversalResponse
import com.polstrat.cadre.modelClass.requestModel.VerifyOtpRequest
import com.polstrat.cadre.networkClient.NetworkResult
import com.polstrat.cadre.repositories.LoginRepository
import kotlinx.coroutines.flow.Flow

class LoginViewModel(
    application: Application
) : BaseViewModel(application) {

    fun releaseViewModel() {
        onCleared()
    }

    private var loginRepository: LoginRepository =
        LoginRepository(application)

    suspend fun sendOTP(
        phone: String
    ): Flow<NetworkResult<UniversalResponse>> {
        return loginRepository.sendOTP(phone)
    }

    suspend fun verifyOTP(
        verifyOtpRequest: VerifyOtpRequest
    ): Flow<NetworkResult<UniversalResponse>> {
        return loginRepository.verifyOTP(verifyOtpRequest)
    }

}