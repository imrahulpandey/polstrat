package com.polstrat.cadre.modelClass.responseModel

data class NotificationMarkedReadResponse(
    val `data`: ReadResponse,
    val error: Any,
    val message: String,
    val status: Boolean
)

data class ReadResponse(
    val acknowledged: Boolean,
    val matchedCount: Int,
    val modifiedCount: Int,
    val upsertedCount: Int,
    val upsertedId: Any
)