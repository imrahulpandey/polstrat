package com.polstrat.cadre.fragment

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.location.Address
import android.location.Geocoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.content.res.AppCompatResources
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatImageView
import androidx.appcompat.widget.LinearLayoutCompat
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Observer
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.move.radianandroid.utils.datastore.DataStoreManager
import com.polstrat.cadre.CustomDialog
import com.polstrat.cadre.PolstratAndroidApplication
import com.polstrat.cadre.R
import com.polstrat.cadre.adapterClass.SubmitImageAdapter
import com.polstrat.cadre.adapterClass.SubmittedImageAdapter
import com.polstrat.cadre.databinding.FragmentTaskDetailsBinding
import com.polstrat.cadre.databinding.LytNewCameraGalleryPickerDialogBinding
import com.polstrat.cadre.modelClass.requestModel.UpdateStatusRequest
import com.polstrat.cadre.modelClass.requestModel.UploadImage
import com.polstrat.cadre.modelClass.responseModel.GetImageData
import com.polstrat.cadre.modelClass.responseModel.TaskUpdatedResponseModel
import com.polstrat.cadre.modelClass.responseModel.UserTasks
import com.polstrat.cadre.networkClient.APIInterface
import com.polstrat.cadre.networkClient.ServiceBuilder
import com.polstrat.cadre.utils.BaseFragment
import com.polstrat.cadre.utils.Constants
import com.polstrat.cadre.utils.Constants.getFileExtension
import com.polstrat.cadre.utils.Constants.getMimeType
import com.polstrat.cadre.utils.LoaderDialog
import com.polstrat.cadre.utils.Spec
import com.polstrat.cadre.viewModels.TasksViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class TaskDetailsFragment : BaseFragment(), Spec, OnMapReadyCallback, GoogleMap.OnMapClickListener {

    lateinit var binding: FragmentTaskDetailsBinding
    private val tasksViewModel: TasksViewModel by activityViewModels()
    private var userTaskData: UserTasks? = null
    private lateinit var googleMap: GoogleMap
    private var submitImageAdapter: SubmitImageAdapter? = null
    private var uploadedImages = ArrayList<UploadImage>()
    private var btnComplete: AppCompatButton? = null
    private var loaderImageView: AppCompatImageView? = null
    private lateinit var loaderDialog: LoaderDialog
    private var currentPhotoPath: String? = null
    private var currentPhotoName: String? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = DataBindingUtil.inflate(
            inflater,
            R.layout.fragment_task_details,
            container,
            false
        )
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.apply {
            presenter = this@TaskDetailsFragment
            lifecycleOwner = this@TaskDetailsFragment
            executePendingBindings()
        }
        binding.mapView.onCreate(savedInstanceState)
        binding.mapView.getMapAsync(this)
        setUpResources()
    }

    override fun setUpResources() {
        setBottomNavVisibility(View.GONE)
        setRecyclerViewContainer()
        loaderDialog = LoaderDialog(requireContext())
    }

    override fun onResume() {
        super.onResume()
        tasksViewModel.getUserTaskData().observe(viewLifecycleOwner, observUserData)
    }

    private val observUserData: Observer<UserTasks> = Observer { response ->
        Log.d(TAG, "data:: $response")
        userTaskData = response
        Log.d(TAG, "$userTaskData")
        binding.apply {
            TaskTitle.text = userTaskData?.title
            userTaskData?.priority.let { priority ->
                when (priority) {
                    "high" -> {
                        Priority.background = AppCompatResources.getDrawable(
                            requireContext(),
                            R.drawable.high_priority_background
                        )
                    }

                    "medium" -> {
                        Priority.background = AppCompatResources.getDrawable(
                            requireContext(),
                            R.drawable.medium_priority_background
                        )
                    }

                    "low" -> {
                        Priority.background = AppCompatResources.getDrawable(
                            requireContext(),
                            R.drawable.low_priority_background
                        )
                    }
                }
                Priority.text = priority
            }

            userTaskData?.status.let { status ->
                when (status) {
                    "inProgress" -> {
                        txtStatus.background = AppCompatResources.getDrawable(
                            requireContext(),
                            R.drawable.medium_priority_background
                        )
                        txtStatus.text = status
                        btnProceed.text = resources.getString(R.string.mark_as_complete)
                        btnProceed.background = AppCompatResources.getDrawable(
                            requireContext(),
                            R.drawable.button_background
                        )
                    }

                    "assigned" -> {
                        txtStatus.background = AppCompatResources.getDrawable(
                            requireContext(),
                            R.drawable.new_task_bg
                        )
                        txtStatus.text = "New Task"
                        btnProceed.text = "Start"
                        btnProceed.background = AppCompatResources.getDrawable(
                            requireContext(),
                            R.drawable.button_green_background
                        )
                    }

                    "complete", "pendingApproval" -> {
                        txtStatus.background = AppCompatResources.getDrawable(
                            requireContext(),
                            R.drawable.complete_task_bg
                        )
                        txtStatus.text = resources.getString(R.string.complete)
                        btnProceed.visibility = View.GONE
                    }
                }

            }

            txtCat.text = userTaskData?.categoryName
            txtSubCat.text = userTaskData?.subCategoryName

            userTaskData?.dueDate?.let {
                if (Constants.isDueDatePassed(it)) {
                    txtDueDate.setTextColor(requireContext().getColor(R.color.delay))
                } else {
                    txtDueDate.setTextColor(requireContext().getColor(R.color.black))
                }
                txtDueDate.text = Constants.convertDateFormat(it)
            }

            txtOfc.text = userTaskData?.officeName
            Instructions.text = userTaskData?.description

            if (!userTaskData!!.uploadImages.isNullOrEmpty()) {
                setImages(userTaskData!!.uploadImages as ArrayList)
            } else {
                binding.rvPhotos.visibility = View.GONE
                binding.emptyImageMess.visibility = View.VISIBLE
            }

            if (!userTaskData!!.postCompletionImages.isNullOrEmpty()) {
                setSubmittedImage(userTaskData!!.postCompletionImages as ArrayList)
            }
        }
    }

    private fun setImages(imgResources: ArrayList<UploadImage>) {
        binding.rvPhotos.visibility = View.VISIBLE
        binding.rvPhotos.layoutManager = GridLayoutManager(requireContext(), 4)

        val imageAdapter =
            SubmittedImageAdapter(requireContext(), imgResources) { image ->
                val zoomDia = CustomDialog(requireContext(), image)
                zoomDia.show()
            }

        binding.rvPhotos.adapter = imageAdapter
    }

    private fun setSubmittedImage(imgResources: ArrayList<UploadImage>) {
        binding.SubmittedPhotosTv.visibility = View.VISIBLE
        binding.rvSubmittedPhotos.visibility = View.VISIBLE
        binding.rvSubmittedPhotos.layoutManager = GridLayoutManager(requireContext(), 4)

        val submittedImageAdapter =
            SubmittedImageAdapter(requireContext(), imgResources) { image ->
                val zoomDia = CustomDialog(requireContext(), image)
                zoomDia.show()
            }

        binding.rvSubmittedPhotos.adapter = submittedImageAdapter
    }

    private fun createDynamicImageView(ll: LinearLayout, publicUrl: String) {
        val imageView = AppCompatImageView(requireContext())

        // Set the image resource programmatically
        Glide.with(requireContext())
            .load(publicUrl)
            .diskCacheStrategy(
                DiskCacheStrategy.RESOURCE
            )
            .into(imageView)

        // Set other attributes if needed
        val params = LinearLayoutCompat.LayoutParams(
            Constants.dpToPx(resources, 69),
            Constants.dpToPx(resources, 69)
        )

        // Set the margins
        params.setMargins(
            Constants.dpToPx(resources, 5),
            Constants.dpToPx(resources, 5),
            Constants.dpToPx(resources, 5),
            Constants.dpToPx(resources, 5)
        )
        imageView.elevation = 5F
        imageView.scaleType = ImageView.ScaleType.FIT_XY
        imageView.layoutParams = params
        // Add ImageView to the layout
        imageView.setOnClickListener {
            val zoomPhoto = CustomDialog(requireContext(), publicUrl)
            zoomPhoto.show()
        }
        ll.addView(imageView)
    }

    fun goBack() {
        requireActivity().onBackPressedDispatcher.onBackPressed()
    }

    private suspend fun updateTask(statusRequest: UpdateStatusRequest) {
        loaderDialog.show()
        val retrofitInterface: APIInterface = ServiceBuilder.retrofitInstance
        val call = userTaskData?.id?.let {
            retrofitInterface.updateTask(
                it,
                "Bearer ${DataStoreManager(requireContext()).getCadreToken()}",
                statusRequest
            )
        }
        call?.enqueue(object : Callback<TaskUpdatedResponseModel?> {
            override fun onResponse(
                call: Call<TaskUpdatedResponseModel?>,
                response: Response<TaskUpdatedResponseModel?>
            ) {
                if (response.isSuccessful) {
                    Log.d(TAG, "response ${response.body()}")
                    if (response.body()?.data != null) {
                        loaderDialog.dismiss()
                        response.body()?.message?.let { showToastShort(requireContext(), it) }
                        if (response.body()?.status == true) {
                            binding.btnProceed.visibility = View.GONE
                            goBack()
                        }
                    }
                }
            }

            override fun onFailure(call: Call<TaskUpdatedResponseModel?>, t: Throwable) {
                Log.i(TAG, t.message.toString())
                loaderDialog.dismiss()
                t.message?.let { showToastShort(requireContext(), it) }
            }
        })
    }

    fun onClickProceed() {
        if (userTaskData?.status == "assigned") {
            lifecycleScope.launchWhenResumed {
                updateTask(UpdateStatusRequest("inProgress", uploadedImages))
            }
        } else {
            if (uploadedImages.isNotEmpty()) {
                lifecycleScope.launchWhenResumed {
                    updateTask(UpdateStatusRequest("pendingApproval", uploadedImages))
                }
            } else {
                binding.llSubmit.visibility = View.VISIBLE
                binding.btnProceed.visibility = View.GONE
            }

        }

    }

    override fun onDestroyView() {
        super.onDestroyView()
        shutDown()
    }

    override fun shutDown() {
        //doSomething
    }

    companion object {
        const val TAG = "TaskDetailsFragment"
        private const val LOCATION_PERMISSION_REQUEST_CODE = 1
        private const val FILENAME = "yyyy-MM-dd-HH-mm-ss-SSS"
        fun createFile(baseFolder: File, format: String, extension: String) = File(
            baseFolder,
            SimpleDateFormat(format, Locale.US).format(System.currentTimeMillis()) + extension
        )

    }

    override fun onMapReady(p0: GoogleMap) {
        p0.let {
            val defaultLocation =
                userTaskData?.location?.lng?.let {
                    userTaskData?.location?.lat?.toDouble()
                        ?.let { it1 -> LatLng(it1, it.toDouble()) }
                }
            googleMap = it
            defaultLocation?.let { it1 -> CameraUpdateFactory.newLatLngZoom(it1, 15f) }
                ?.let { it2 -> googleMap.moveCamera(it2) }
            enableMyLocation()
            googleMap.setOnMapClickListener(this)
            if (defaultLocation != null) {
                showAddress(defaultLocation)
            }
        }
    }

    private fun enableMyLocation() {
        if (ContextCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION
            )
            == PackageManager.PERMISSION_GRANTED
        ) {
            googleMap.isMyLocationEnabled = true
        } else {
            ActivityCompat.requestPermissions(
                requireActivity(),
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST_CODE
            )
        }
    }

    private fun showAddress(latLng: LatLng) {
        val geocoder = Geocoder(requireContext(), Locale.getDefault())
        try {
            val addresses: MutableList<Address>? =
                geocoder.getFromLocation(latLng.latitude, latLng.longitude, 1)
            if (addresses?.isNotEmpty() == true) {
                val address = addresses[0]
                val addressText = address.getAddressLine(0)
                googleMap.clear() // Clear existing markers


                val vectorDrawable = ContextCompat.getDrawable(requireContext(), R.drawable.marker)
                val bitmap = Bitmap.createBitmap(
                    vectorDrawable?.intrinsicWidth ?: 0,
                    vectorDrawable?.intrinsicHeight ?: 0,
                    Bitmap.Config.ARGB_8888
                )
                val canvas = Canvas(bitmap)
                vectorDrawable?.setBounds(0, 0, canvas.width, canvas.height)
                vectorDrawable?.draw(canvas)

                val customMarker = BitmapDescriptorFactory.fromBitmap(bitmap)
                val marker = MarkerOptions().position(latLng).title(addressText).icon(customMarker)
                googleMap.addMarker(marker)
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                enableMyLocation()
            }
        }
    }

    private fun setRecyclerViewContainer() {
        loaderImageView = requireView().findViewById(R.id.uploadLoader)
        val addImages: AppCompatImageView = requireView().findViewById(R.id.imgsAdd)
        addImages.setOnClickListener {
            showPickerDialog()
        }

        val recyclerView: RecyclerView = requireView().findViewById(R.id.rvSubmittedImages)
        recyclerView.layoutManager = GridLayoutManager(requireContext(), 4)
        submitImageAdapter = SubmitImageAdapter(requireContext()) { images ->
            val zoomDia = CustomDialog(requireContext(), images)
            zoomDia.show()
        }
        recyclerView.adapter = submitImageAdapter

        btnComplete = requireView().findViewById(R.id.btnMarkAsComplete)
        btnComplete?.setOnClickListener {
            if (uploadedImages.isNotEmpty()) {
                lifecycleScope.launchWhenResumed {
                    updateTask(UpdateStatusRequest("pendingApproval", uploadedImages))
                }
            } else {
                showToastShort(requireContext(), "Upload images!")
            }
        }
    }

    private val requestGalleryPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { grantResults ->
        if (grantResults) {
            setProfilePicFromGallery()
        } else {
            showToastShort(requireContext(), "Go to setting and allow permission")
        }

    }

    private fun setProfilePicFromGallery() {
        galleryContract.launch("image/*")
    }

    private val galleryContract =
        registerForActivityResult(ActivityResultContracts.GetMultipleContents()) {
            if (it != null) {
                btnComplete?.visibility = View.GONE
                loaderImageView?.visibility = View.VISIBLE
                binding.loader.startAnimation(
                    AnimationUtils.loadAnimation(
                        requireContext(),
                        R.anim.loader_animation
                    )
                )
                createMultipleFile(it)
            }
        }

    private fun createMultipleFile(uri: List<Uri>) {
        val imageParts = mutableListOf<MultipartBody.Part>()
        for (imageUri in uri) {
            val file = getOutputDirectory()
            val inputStream = requireContext().contentResolver.openInputStream(imageUri)
            val filePath =
                createFile(
                    file,
                    FILENAME,
                    ".${getFileExtension(requireContext(), imageUri)}"
                )
            val outputStream = FileOutputStream(filePath)
            inputStream?.copyTo(outputStream)
            Log.d(TAG, "fileName: $imageUri")
            Log.d(
                TAG, "Selected MIME type: ${
                    getMimeType(
                        requireContext(),
                        imageUri
                    )
                }\n Extension: ${
                    getFileExtension(requireContext(), imageUri)
                }"
            )

            val request = RequestBody.create(
                MediaType.parse(getMimeType(requireContext(), imageUri).toString()),
                filePath.absoluteFile
            )
            val body = request.let {
                MultipartBody.Part.createFormData(
                    "grievanceImages", filePath.name, it
                )
            }
            imageParts.add(body)
        }
        uploadMultipleImages(imageParts)
    }

    private fun checkGalleryPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            PackageManager.PERMISSION_GRANTED == ActivityCompat.checkSelfPermission(
                PolstratAndroidApplication.appContext, Manifest.permission.READ_MEDIA_IMAGES
            )
        } else {
            PackageManager.PERMISSION_GRANTED == ActivityCompat.checkSelfPermission(
                PolstratAndroidApplication.appContext, Manifest.permission.READ_EXTERNAL_STORAGE
            )
        }
    }

    private fun uploadMultipleImages(part: List<MultipartBody.Part>) {
        val retrofitInterface: APIInterface = ServiceBuilder.retrofitInstance
        CoroutineScope(Dispatchers.IO).launch {
            val call = retrofitInterface.uploadImages(
                part, "Bearer ${DataStoreManager(requireContext()).getCadreToken()}"
            )

            call.enqueue(object : Callback<GetImageData> {
                override fun onResponse(
                    call: Call<GetImageData?>, response: Response<GetImageData?>
                ) {
                    if (response.isSuccessful) {
                        Log.d(TAG, "response ${response.body()}")
                        loaderImageView?.clearAnimation()
                        loaderImageView?.visibility = View.GONE
                        for (url in response.body()?.data as ArrayList<UploadImage>) {
                            uploadedImages.add(url)
                        }
                        submitImageAdapter?.updateList(uploadedImages)
                        response.body()?.let { showToastShort(requireContext(), it.message) }
                        btnComplete?.visibility = View.VISIBLE
                    }
                }

                override fun onFailure(call: Call<GetImageData?>, t: Throwable) {
                    Log.i(TAG, t.message.toString())
                    loaderImageView?.clearAnimation()
                    loaderImageView?.visibility = View.GONE
                    btnComplete?.visibility = View.VISIBLE
                }
            })
        }
    }

    private fun getOutputDirectory(): File {
        val mediaDir = requireActivity().externalMediaDirs.firstOrNull()?.let {
            File(it, "image").apply { mkdirs() }
        }
        return if (mediaDir != null && mediaDir.exists()) mediaDir else requireActivity().filesDir
    }


    private fun showPickerDialog() {
        val dialog = BottomSheetDialog(requireContext(), R.style.AppBottomSheetDialogTheme)
        val binding: LytNewCameraGalleryPickerDialogBinding = DataBindingUtil.inflate(
            layoutInflater, R.layout.lyt_new_camera_gallery_picker_dialog, null, true
        )

        binding.btnCamera.setOnClickListener {
            dialog.dismiss()
            if (checkCameraPermission()) {
                lifecycleScope.launchWhenResumed {
                    setProfilePicFromCamera()
                }
            } else {
                requestCameraPermission.launch(Manifest.permission.CAMERA)
            }
        }

        binding.btnGallery.setOnClickListener {
            dialog.dismiss()
            if (checkGalleryPermission()) {
                lifecycleScope.launchWhenResumed {
                    setProfilePicFromGallery()
                }
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    requestGalleryPermission.launch(Manifest.permission.READ_MEDIA_IMAGES)
                } else {
                    requestGalleryPermission.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                }
            }
        }
        binding.btnCancel.setOnClickListener {
            dialog.dismiss()
        }

        dialog.setContentView(binding.root)
        dialog.show()
    }

    private fun checkCameraPermission(): Boolean {
        return PackageManager.PERMISSION_GRANTED == ActivityCompat.checkSelfPermission(
            PolstratAndroidApplication.appContext, Manifest.permission.CAMERA
        )
    }

    private val requestCameraPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { grantResults ->
        if (grantResults) {
            setProfilePicFromCamera()
        } else {
            showToastShort(requireContext(), "Go to setting and allow permission")
        }

    }

    private fun setProfilePicFromCamera() {
        Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
            takePictureIntent.resolveActivity(PolstratAndroidApplication.appContext.packageManager)
                ?.also {
                    // Create the File where the photo should go
                    val photoFile: File? = try {
                        createImageFile()
                    } catch (ex: IOException) {
                        // Error occurred while creating the File
                        null
                    }
                    // Continue only if the File was successfully created
                    photoFile?.also {
                        val photoURI: Uri = FileProvider.getUriForFile(
                            requireContext(),
                            "com.polstrat.cadre.provider",
                            it
                        )
                        takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                        takePicture.launch(takePictureIntent)
                    }
                }
        }
    }

    private val takePicture =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                if (!currentPhotoName.isNullOrEmpty() && !currentPhotoPath.isNullOrEmpty()) {
                    val imageParts = mutableListOf<MultipartBody.Part>()

                    val file = currentPhotoPath?.let { File(it) }
                    if (file?.exists() == true) {
                        println("${currentPhotoName},$currentPhotoPath")
                        // submitImageAdapter?.updateList(imageUri)
                        Log.d(TAG, "imageUri: ${Uri.parse(currentPhotoPath)}")

                        val requestBody = file.let {
                            RequestBody.create(
                                MediaType.parse("image"), it
                            )
                        }
                        val part = requestBody.let {
                            MultipartBody.Part.createFormData(
                                "grievanceImages",
                                currentPhotoName,
                                it
                            )
                        }
                        imageParts.add(part)
                        uploadMultipleImages(imageParts)
                    } else {
                        //file not found please select another file.
                        showToastShort(requireContext(), "File not found")
                    }
                }
            }
        }

    private fun createImageFile(): File {
        // Create an image file name
        val timeStamp: String = SimpleDateFormat(FILENAME).format(Date())
        val storageDir: File? =
            PolstratAndroidApplication.appContext.getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile(
            timeStamp, /* prefix */
            ".jpg", /* suffix */
            storageDir /* directory */
        ).apply {
            // Save a file: path for use with ACTION_VIEW intents
            currentPhotoName = this.name
            currentPhotoPath = absolutePath
        }
    }


    override fun onMapClick(p0: LatLng) {
        /* val bundle = Bundle()
         bundle.putString(Constants.ADDRESS, userTaskData?.location?.address)
         bundle.putString(Constants.LATITUDE, userTaskData?.location?.lat)
         bundle.putString(Constants.LONGITUDE, userTaskData?.location?.lng)
         if (isAdded && findNavController().currentDestination?.label == "TaskDetailsFragment") {
 //            findNavController().navigate(R.id.action_taskDetailsFragment_to_mapFragment, bundle)
             findNavController().navigate(
                 R.id.action_taskDetailsFragment_to_revisedMapFragment,
                 bundle
             )
         }*/
    }
}