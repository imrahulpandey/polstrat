package com.polstrat.cadre.utils

interface Spec {
    fun setUpResources()
    fun shutDown()
}