package com.polstrat.cadre

import android.app.Dialog
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.view.Window
import android.widget.ImageView
import androidx.appcompat.widget.LinearLayoutCompat
import androidx.constraintlayout.widget.ConstraintLayout
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.github.chrisbanes.photoview.PhotoView
import com.polstrat.cadre.utils.Constants
import com.polstrat.cadre.utils.Constants.getDeviceHeight
import com.polstrat.cadre.utils.Constants.getDeviceWidth

class CustomDialog(context: Context, private val imageUri: String) :
    Dialog(context) {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.custom_dialog_layout)

        // Initialize views
        val photoView = findViewById<PhotoView>(R.id.photoView)
        Glide.with(context)
            .load(imageUri)
            .diskCacheStrategy(
                DiskCacheStrategy.RESOURCE
            )
            .into(photoView)
    }
}