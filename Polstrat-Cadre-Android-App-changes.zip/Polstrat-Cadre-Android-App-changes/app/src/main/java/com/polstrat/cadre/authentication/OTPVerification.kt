package com.polstrat.cadre.authentication

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.view.animation.AnimationUtils
import android.view.inputmethod.InputMethodManager
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.lifecycleScope
import com.move.radianandroid.utils.datastore.DataStoreManager
import com.polstrat.cadre.R
import com.polstrat.cadre.databinding.ActivityOtpVerificationBinding
import com.polstrat.cadre.modelClass.requestModel.VerifyOtpRequest
import com.polstrat.cadre.modelClass.responseModel.UniversalResponse
import com.polstrat.cadre.networkClient.NetworkResult
import com.polstrat.cadre.utils.BaseActivity
import com.polstrat.cadre.utils.Constants.MOB_NUMBER
import com.polstrat.cadre.utils.Constants.hideKeyboard
import com.polstrat.cadre.utils.LoaderDialog
import com.polstrat.cadre.utils.Spec
import com.polstrat.cadre.viewModels.LoginViewModel
import kotlinx.coroutines.flow.FlowCollector

class OTPVerification : BaseActivity(), Spec {

    private lateinit var binding: ActivityOtpVerificationBinding
    private var loginViewModel: LoginViewModel? = null
    private var numb = ""
    private lateinit var loaderDialog: LoaderDialog

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_otp_verification)
        setUpResources()
    }

    fun goBack() {
        finish()
    }

    fun resendOTP() {
        lifecycleScope.launchWhenStarted {
            loginViewModel?.sendOTP(
                numb
            )?.collect(resendStatsCollector)
        }
    }

    private val resendStatsCollector: FlowCollector<NetworkResult<UniversalResponse>> =
        FlowCollector { response ->
            when (response) {
                is NetworkResult.Loading -> {
                    loaderDialog.show()
                }

                is NetworkResult.Success -> {
                    response.data?.let {
                        loaderDialog.dismiss()
                        it.message?.let { it1 -> showToastShort(this, it1) }
                    }
                }

                is NetworkResult.Error -> {
                    Log.e(TAG, "response error ${response.message}")
                    loaderDialog.dismiss()
                    showToastShort(this, response.message)
                }
            }
        }

    fun verifyOTP() {
        val verifyOtpRequest = VerifyOtpRequest(numb, binding.otp.text.toString())
        lifecycleScope.launchWhenStarted {
            loginViewModel?.verifyOTP(
                verifyOtpRequest
            )?.collect(statsCollector)
        }
    }

    private val statsCollector: FlowCollector<NetworkResult<UniversalResponse>> =
        FlowCollector { response ->
            when (response) {
                is NetworkResult.Loading -> {
                    loaderDialog.show()
                }

                is NetworkResult.Success -> {
                    response.data?.let {
                        loaderDialog.dismiss()
                        it.message?.let { it1 -> showToastShort(this, it1) }
                        if (it.message == "Incorrect OTP. Please try again.") {
                            binding.txtIncorrectOtp.visibility = View.VISIBLE
                        } else {
                            Log.d(TAG, "$it")
                            it.data?.clientUser?.id.let { it1 ->
                                if (it1 != null) {
                                    DataStoreManager(this).saveClientId(it1)
                                }
                            }
                            it.data?.clientUser?.constituencyId.let { it1 ->
                                if (it1 != null) {
                                    DataStoreManager(this).saveConstituencyId(it1)
                                }
                            }
                            it.data?.token.let { it1 ->
                                if (it1 != null) {
                                    DataStoreManager(this).saveToken(it1)
                                }
                            }
                            it.data?.clientUser?.cadreToken.let { it1 ->
                                if (it1 != null) {
                                    DataStoreManager(this).saveCadreToken(it1)
                                }
                            }
                            it.data?.clientUser?.firstName.let { it1 ->
                                if (it1 != null) {
                                    DataStoreManager(this).saveFName(it1)
                                }
                            }
                            it.data?.clientUser?.lastName.let { it1 ->
                                if (it1 != null) {
                                    DataStoreManager(this).saveLName(it1)
                                }
                            }
                            it.data?.clientUser?.role.let { it1 ->
                                if (it1 != null) {
                                    DataStoreManager(this).saveRole(it1)
                                }
                            }
                            it.data?.clientUser?.email.let { it1 ->
                                if (it1 != null) {
                                    DataStoreManager(this).saveEmail(it1)
                                }
                            }
                            it.data?.clientUser?.profileImageLink.let { it1 ->
                                if (it1 != null) {
                                    DataStoreManager(this).saveProfilePic(it1)
                                }
                            }
                            startActivity(
                                Intent(
                                    this@OTPVerification,
                                    VerificationSuccessful::class.java
                                )
                            )
                            finish()
                        }
                    }
                }

                is NetworkResult.Error -> {
                    Log.e(TAG, "response error ${response.message}")
                    loaderDialog.dismiss()
                    showToastShort(this, response.message)
                }
            }
        }

    companion object {
        const val TAG = "OTPVerificationActivity"
    }

    override fun setUpResources() {
        binding.apply {
            presenter = this@OTPVerification
            lifecycleOwner = this@OTPVerification
            executePendingBindings()
        }
        loginViewModel = LoginViewModel(application)
        loaderDialog = LoaderDialog(this)
        val intent = intent
        numb = intent.getStringExtra(MOB_NUMBER).toString()
        Log.d(TAG, numb)
        binding.txtNumb.text = "Enter OTP code send on +91-$numb"

        binding.otp.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                //write your login
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                //write your login
            }

            override fun afterTextChanged(s: Editable?) {
                if (s?.length == 4) {
                    val imm =
                        getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                    imm.hideSoftInputFromWindow(binding.otp.windowToken, 0)
                }
            }

        })
    }

    override fun shutDown() {
        TODO("Not yet implemented")
    }
}