package com.polstrat.cadre.adapterClass

import android.graphics.PorterDuff
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.paging.PagingDataAdapter
import androidx.recyclerview.widget.RecyclerView
import com.polstrat.cadre.PolstratAndroidApplication
import com.polstrat.cadre.R
import com.polstrat.cadre.diffUtils.TaskDiffUtilClass
import com.polstrat.cadre.databinding.ListTaskItemsBinding
import com.polstrat.cadre.fragment.TasksFragment
import com.polstrat.cadre.modelClass.responseModel.UserTasks
import com.polstrat.cadre.utils.Constants
import com.polstrat.cadre.utils.Constants.convertDateFormat

class TasksListAdapter(val presenterFrag: TasksFragment) :
    PagingDataAdapter<UserTasks, TasksListAdapter.ViewHolder>(TaskDiffUtilClass()) {
    private var context = PolstratAndroidApplication.appContext

    inner class ViewHolder(val binding: ListTaskItemsBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(userTaskData: UserTasks, position: Int) {
            binding.apply {
                presenter = presenterFrag
                userData = userTaskData

                when (userTaskData.priority) {
                    "high" -> {
                        txtPriority.background = AppCompatResources.getDrawable(
                            context,
                            R.drawable.high_priority_background
                        )
                    }

                    "medium" -> {
                        txtPriority.background = AppCompatResources.getDrawable(
                            context,
                            R.drawable.medium_priority_background
                        )
                    }

                    "low" -> {
                        txtPriority.background = AppCompatResources.getDrawable(
                            context,
                            R.drawable.low_priority_background
                        )
                    }
                }
                txtPriority.text = userTaskData.priority

                if (userTaskData.status == Constants.COMPLETE) {
                    imgCheck.visibility = View.VISIBLE
                } else {
                    imgCheck.visibility = View.GONE
                }

                txtTaskName.text = userTaskData.title
                txtDesc.text = userTaskData.description
                txtAddr.text = userTaskData.location?.address
                userTaskData.dueDate?.let {
                    if (Constants.isDueDatePassed(it)) {
                        dueDate.setTextColor(context.getColor(R.color.delay))
                        imgCalWarn.setColorFilter(
                            ContextCompat.getColor(context, R.color.delay),
                            PorterDuff.Mode.SRC_IN
                        )
                    } else {
                        dueDate.setTextColor(context.getColor(R.color.black))
                        imgCalWarn.setColorFilter(
                            ContextCompat.getColor(context, R.color.black),
                            PorterDuff.Mode.SRC_IN
                        )
                    }
                    dueDate.text = convertDateFormat(it)
                }
            }

        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TasksListAdapter.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding: ListTaskItemsBinding =
            DataBindingUtil.inflate(inflater, R.layout.list_task_items, parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TasksListAdapter.ViewHolder, position: Int) {
        getItem(position)?.let { holder.bind(it, position) }
    }
}