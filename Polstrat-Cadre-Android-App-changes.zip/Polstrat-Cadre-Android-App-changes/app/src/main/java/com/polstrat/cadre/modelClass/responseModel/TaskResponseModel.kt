package com.polstrat.cadre.modelClass.responseModel

import com.google.gson.annotations.SerializedName

data class TaskResponseModel(
    val data: ArrayList<Data>? = null,
    val error: String? = null,
    val message: String? = null,
    val status: Boolean? = false
)

data class Data(
    @SerializedName("_id")
    val id: String? = null,
    val count: Int? = null,
    val new: Int? = null
)

data class PieChartValues(
    val percent: String? = null,
    val color: String? = null,
)