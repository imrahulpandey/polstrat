package com.polstrat.cadre.adapterClass

import android.util.Log
import androidx.paging.PagingSource
import androidx.paging.PagingState
import com.polstrat.cadre.modelClass.responseModel.NotificationList
import com.polstrat.cadre.networkClient.APIInterface

class NotificationPagingSource(
    private val apiInterface: APIInterface,
    val token: String
) : PagingSource<Int, NotificationList>() {

    companion object {
        const val STARTING_PAGE_INDEX = 1
    }
    override fun getRefreshKey(state: PagingState<Int, NotificationList>): Int? {
        return state.anchorPosition?.let { anchorPosition ->
            state.closestPageToPosition(anchorPosition)?.prevKey?.plus(1)
                ?: state.closestPageToPosition(anchorPosition)?.nextKey?.minus(1)
        }
    }

    override suspend fun load(params: LoadParams<Int>): LoadResult<Int, NotificationList> {
        val pageIndex = params.key ?: STARTING_PAGE_INDEX
        return try {
            val response = apiInterface.getNotifications(
                pageIndex,
                10,
                token
            )
            val notificationData = response.body()?.message?.data

            Log.d("TAG", "NotificationList>> $notificationData")
            LoadResult.Page(
                data = notificationData ?: listOf(),
                prevKey = if (pageIndex == STARTING_PAGE_INDEX) null else pageIndex - 1,
                nextKey = if (notificationData?.isEmpty() == true) null else pageIndex + 1
            )
        } catch (exception: Exception) {
            return LoadResult.Error(exception)
        }
    }
}