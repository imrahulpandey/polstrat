package com.polstrat.cadre.modelClass

import com.google.gson.annotations.SerializedName

data class Categories(
    @SerializedName("data")
    val data: List<Data>,
    val error: Any,
    val message: String,
    val status: Boolean
)

data class Data(
    @SerializedName("_id")
    val id: String,
    val createdBy: String,
    val description: String,
    val name: String,
    val subcategories: List<Subcategory>
)

data class Subcategory(
    @SerializedName("_id")
    val id: String,
    val createdBy: String,
    val description: String,
    val name: String
)