package com.polstrat.cadre.repositories

import android.content.Context
import com.polstrat.cadre.networkClient.APIInterface
import com.polstrat.cadre.networkClient.ServiceBuilder

open class BaseRepository(protected val context: Context) {
    protected val retrofitInterface: APIInterface = ServiceBuilder.retrofitInstance
}
