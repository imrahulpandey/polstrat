package com.polstrat.cadre.fragment

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.move.radianandroid.utils.datastore.DataStoreManager
import com.polstrat.cadre.R
import com.polstrat.cadre.authentication.Login
import com.polstrat.cadre.databinding.FragmentProfileBinding
import com.polstrat.cadre.utils.BaseFragment
import com.polstrat.cadre.utils.Spec
import com.polstrat.cadre.viewModels.FormViewModel
import com.polstrat.cadre.viewModels.MainViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ProfileFragment : BaseFragment(), Spec {

    lateinit var binding: FragmentProfileBinding
    private val formViewModel: FormViewModel by activityViewModels()
    private val mainViewModel: MainViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding =
            DataBindingUtil.inflate(layoutInflater, R.layout.fragment_profile, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.apply {
            presenter = this@ProfileFragment
            lifecycleOwner = this@ProfileFragment
            executePendingBindings()
        }
        setUpResources()

        mainViewModel.redirectToNotif.observe(viewLifecycleOwner) {
            if (it.equals("true")) {
                openNotification()
            }
        }

        CoroutineScope(Dispatchers.Default).launch {
            if (DataStoreManager(requireContext()).getNotificationReceived() == "true") {
                binding.Notification.setImageResource(R.drawable.unread_notification_ic)
            } else {
                binding.Notification.setImageResource(R.drawable.read_notification_ic)
            }
        }

        mainViewModel.isNotificationReceived.observe(viewLifecycleOwner) {
            if (it.equals("true")) {
                binding.Notification.setImageResource(R.drawable.unread_notification_ic)
            } else {
                binding.Notification.setImageResource(R.drawable.read_notification_ic)
            }
        }
    }

    fun openNotification() {
        if (isAdded && findNavController().currentDestination?.label == getString(R.string.profile_fragment_label)) {
            lifecycleScope.launchWhenResumed {
                findNavController().navigate(R.id.action_profileFragment_to_notificationFragment)
            }
        }
    }

    fun viewProfile() {
        if (isAdded && findNavController().currentDestination?.label == getString(R.string.profile_fragment_label)) {
            lifecycleScope.launchWhenResumed {
                findNavController().navigate(R.id.action_profileFragment_to_viewProfileFragment)
            }
        }
    }

    fun reportAnIssue() {
        if (isAdded && findNavController().currentDestination?.label == getString(R.string.profile_fragment_label)) {
            lifecycleScope.launchWhenResumed {
                findNavController().navigate(R.id.action_profileFragment_to_reportIssueFragment)
            }
        }
    }

    fun logOut() {
        lifecycleScope.launch {
            DataStoreManager(requireContext()).saveClientId("")
            DataStoreManager(requireContext()).saveToken("")
            DataStoreManager(requireContext()).saveCadreToken("")
            DataStoreManager(requireContext()).saveFName("")
            DataStoreManager(requireContext()).saveLName("")
            DataStoreManager(requireContext()).saveRole("")
            DataStoreManager(requireContext()).saveEmail("")
            DataStoreManager(requireContext()).saveConstituencyId("")
            DataStoreManager(requireContext()).saveProfilePic("")
            val intent = Intent(requireActivity(), Login::class.java)
            startActivity(intent)
            requireActivity().finish()
        }
    }

    override fun setUpResources() {
        setBottomNavVisibility(View.VISIBLE)
        formViewModel.priority = ""
        formViewModel.imageUrl.clear()
        lifecycleScope.launch {
            binding.apply {
                if (DataStoreManager(requireContext()).getProfilePic().isNotEmpty()) {
                    try {
                        Glide.with(requireContext())
                            .load(DataStoreManager(requireContext()).getProfilePic())
                            .diskCacheStrategy(
                                DiskCacheStrategy.RESOURCE
                            )
                            .into(binding.ProfileImage)
                    } catch (e: Exception) {
                        binding.ProfileImage.setImageResource(R.drawable.profile_avatar)
                    }
                } else {
                    binding.ProfileImage.setImageResource(R.drawable.profile_avatar)
                }
                Username.text = "${DataStoreManager(requireContext()).getFName()} ${
                    DataStoreManager(requireContext()).getLName()
                }"
            }
        }

    }

    override fun onDestroyView() {
        super.onDestroyView()
        shutDown()
    }

    override fun shutDown() {
        //doSomething
    }
}