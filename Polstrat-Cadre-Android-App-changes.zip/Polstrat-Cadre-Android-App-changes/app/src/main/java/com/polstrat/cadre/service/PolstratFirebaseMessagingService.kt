package com.polstrat.cadre.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.move.radianandroid.utils.datastore.DataStoreManager
import com.polstrat.cadre.R
import com.polstrat.cadre.fragment.HostActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class PolstratFirebaseMessagingService : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.e(TAG, "fcm token : $token")
        CoroutineScope(Dispatchers.IO).launch {
            DataStoreManager(this@PolstratFirebaseMessagingService).saveFCMToken(token)
        }
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        remoteMessage.data.let {
             val intent = Intent("com.polstrat.cadre.sendNotificationBroadcast")
             intent.putExtra("isReceived", "true")
             LocalBroadcastManager.getInstance(this).sendBroadcast(intent)
        }

        Log.d(TAG, "${remoteMessage.data}")
        Log.d(TAG, "Body:- ${remoteMessage.notification?.body}")
        Log.d(TAG, "Title:- ${remoteMessage.notification?.title}")

        if (remoteMessage.notification != null) {
            val title = remoteMessage.notification?.title
            val body = remoteMessage.notification?.body
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if (!title.isNullOrEmpty() && !body.isNullOrEmpty()) {
                    val intent = Intent(this, HostActivity::class.java)
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    intent.putExtra("source", "true")
                    val pendingIntent = PendingIntent.getActivity(
                        this,
                        0,
                        intent,
                        PendingIntent.FLAG_MUTABLE
                    )

                    val notification = NotificationCompat.Builder(this, "channel777")
                        .setContentTitle(title)
                        .setContentText(body)
                        .setSmallIcon(R.mipmap.ic_launcher)
                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                        .setContentIntent(pendingIntent)
                        .setAutoCancel(true)
                        .setOngoing(true)
                        .setDefaults(NotificationCompat.DEFAULT_ALL)
                        .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                        .build()

                    val manager =
                        getSystemService(NOTIFICATION_SERVICE) as NotificationManager
                    val channel = NotificationChannel(
                        "channel777",
                        "Default channel",
                        NotificationManager.IMPORTANCE_HIGH
                    )
                    manager.createNotificationChannel(channel)
                    manager.notify(777, notification)

                    val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                    vibrator.vibrate(
                        VibrationEffect.createOneShot(
                            500,
                            VibrationEffect.DEFAULT_AMPLITUDE
                        )
                    )
                }
            }
        }
    }

    companion object {
        const val TAG = "FirebaseMessagingService"
    }
}