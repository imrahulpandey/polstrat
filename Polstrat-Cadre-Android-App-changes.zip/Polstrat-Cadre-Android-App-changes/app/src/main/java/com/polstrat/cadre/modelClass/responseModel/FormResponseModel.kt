package com.polstrat.cadre.modelClass.responseModel

data class FormResponseModel(
    val data: FormData,
    val error: Any,
    val message: String,
    val status: Boolean
)

data class FormData(
    val __v: Int,
    val _id: String,
    val categoryId: String,
    val categoryName: String,
    val clientId: String,
    val constituencyId: String,
    val createdAt: String,
    val createdByUserId: String,
    val createdByUserName: String,
    val createdByUserRole: String,
    val description: String,
    val firstName: String,
    val gender: String,
    val lastName: String,
    val location: Location,
    val numberOfPeople: String,
    val officeId: String,
    val phone: Long,
    val postCompletionImages: List<Any>,
    val priority: String,
    val status: String,
    val subCategoryId: String,
    val subCategoryName: String,
    val updatedAt: String,
    val uploadImages: List<UploadImage>,
    val visitorType: String
)

data class UploadImage(
    val guid: String,
    val key: String,
    val name: String
)

data class GetImageData(
    val data: List<com.polstrat.cadre.modelClass.requestModel.UploadImage>,
    val error: Any,
    val message: String,
    val status: Boolean
)