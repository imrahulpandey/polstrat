package com.polstrat.cadre

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView

class CustomSpinnerAdapter(context: Context, resource: Int, objects: List<Any>) :
    ArrayAdapter<Any>(context, resource, objects) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = super.getView(position, convertView, parent) as TextView

        if (position == 0) {
            view.setTextColor(context.getColor(R.color.unselected_tab))
        } else {
            // Reset to default text color for other items
            view.setTextColor(context.getColor(R.color.black))
        }
        return view
    }

    override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
        return getView(position, convertView, parent)
    }

    override fun isEnabled(position: Int): Boolean {
        // Disable the first item
        return position != 0
    }
}