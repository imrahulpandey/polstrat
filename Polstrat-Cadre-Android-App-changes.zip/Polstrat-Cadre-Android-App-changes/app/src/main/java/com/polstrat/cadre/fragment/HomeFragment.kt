package com.polstrat.cadre.fragment

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.move.radianandroid.utils.datastore.DataStoreManager
import com.polstrat.cadre.R
import com.polstrat.cadre.databinding.FragmentHomeBinding
import com.polstrat.cadre.modelClass.responseModel.Data
import com.polstrat.cadre.modelClass.responseModel.PieChartValues
import com.polstrat.cadre.modelClass.responseModel.TaskResponseModel
import com.polstrat.cadre.networkClient.NetworkResult
import com.polstrat.cadre.utils.BaseFragment
import com.polstrat.cadre.viewModels.FormViewModel
import com.polstrat.cadre.viewModels.HomeViewModel
import com.polstrat.cadre.viewModels.MainViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.FlowCollector
import kotlinx.coroutines.launch

class HomeFragment : BaseFragment() {

    lateinit var binding: FragmentHomeBinding
    private val homeViewModel: HomeViewModel by activityViewModels()
    private var pieChartValues = ArrayList<PieChartValues>()
    private val formViewModel: FormViewModel by activityViewModels()
    private val mainViewModel: MainViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = DataBindingUtil.inflate(
            inflater, R.layout.fragment_home, container, false
        )
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.apply {
            presenter = this@HomeFragment
            lifecycleOwner = this@HomeFragment
            executePendingBindings()
        }
        setUpResources()

        mainViewModel.redirectToNotif.observe(viewLifecycleOwner) {
            if (it.equals("true")) {
                openNotification()
            }
        }
    }

    private fun setUpResources() {
        setBottomNavVisibility(View.VISIBLE)
        formViewModel.priority = ""
        formViewModel.imageUrl.clear()
        lifecycleScope.launchWhenStarted {
            binding.apply {
                userName = "${DataStoreManager(requireContext()).getFName()} ${
                    DataStoreManager(requireContext()).getLName()
                }"
                if (DataStoreManager(requireContext()).getRole() == "cadre") {
                    userRole = "Cadre"
                } else if (DataStoreManager(requireContext()).getRole() == "data_entry_operator") {
                    userRole = "Data Entry Operator"
                }
            }

            //TaskGraphAPI
            homeViewModel.getHomeGraphData(
                "Bearer ${DataStoreManager(requireContext()).getCadreToken()}"
            ).collect(statsCollector)

            //TaskPriorityAPI
            homeViewModel.getHomePriorityData(
                "Bearer ${DataStoreManager(requireContext()).getCadreToken()}"
            ).collect(priorityStatsCollector)
        }

        CoroutineScope(Dispatchers.Default).launch {
            if (DataStoreManager(requireContext()).getNotificationReceived() == "true") {
                binding.imgNotifi.setImageResource(R.drawable.unread_notification_ic)
            }else{
                binding.imgNotifi.setImageResource(R.drawable.read_notification_ic)
            }
        }

        mainViewModel.isNotificationReceived.observe(viewLifecycleOwner) {
            if (it.equals("true")) {
                binding.imgNotifi.setImageResource(R.drawable.unread_notification_ic)
            } else {
                binding.imgNotifi.setImageResource(R.drawable.read_notification_ic)
            }
        }
    }

    private val statsCollector: FlowCollector<NetworkResult<TaskResponseModel>> =
        FlowCollector { response ->
            when (response) {
                is NetworkResult.Loading -> {

                }

                is NetworkResult.Success -> {
                    response.data?.let {
                        Log.d(TAG, "$it")
                        binding.apply {
                            if (it.data != null) {
                                for (count in it.data) {
                                    when (count.id) {
                                        "inProgress" -> {
                                            txtProgressCount.text = count.count.toString()
                                        }

                                        "assigned" -> {
                                            txtTasksCount.text = count.count.toString()
                                        }

                                        "complete" -> {
                                            txtCompetedCount.text = count.count.toString()
                                        }

                                        "delayedTasks" -> {
                                            txtDelayCount.text = count.count.toString()
                                        }
                                    }
                                }
                                setPieChart(it.data)
                            }
                        }
                    }
                }

                is NetworkResult.Error -> {
                    Log.e(TAG, "response error ${response.message}")
                }
            }
        }

    private val priorityStatsCollector: FlowCollector<NetworkResult<TaskResponseModel>> =
        FlowCollector { response ->
            when (response) {
                is NetworkResult.Loading -> {}

                is NetworkResult.Success -> {
                    response.data?.let {
                        if (it.data != null) {
                            binding.apply {
                                for (count in it.data) {
                                    when (count.id) {
                                        "high" -> {
                                            progressHighBar.progress = getRatio(
                                                count.count!!.toFloat(),
                                                totalPriority(it.data)
                                            ).toInt()
                                            highData.text =
                                                "${count.count}/${totalPriority(it.data)}"
                                        }

                                        "medium" -> {
                                            progressMediumBar.progress = getRatio(
                                                count.count!!.toFloat(),
                                                totalPriority(it.data)
                                            ).toInt()
                                            mediumData.text =
                                                "${count.count}/${totalPriority(it.data)}"
                                        }

                                        "low" -> {
                                            progressLowBar.progress = getRatio(
                                                count.count!!.toFloat(),
                                                totalPriority(it.data)
                                            ).toInt()
                                            lowData.text =
                                                "${count.count}/${totalPriority(it.data)}"
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                is NetworkResult.Error -> {
                    Log.e(TAG, "response error ${response.message}")

                }
            }
        }

    fun openNotification() {
        if (isAdded && findNavController().currentDestination?.label == getString(R.string.home_fragment_label)) {
            lifecycleScope.launchWhenResumed {
                findNavController().navigate(R.id.action_homeFragment_to_notificationFragment)
            }
        }
    }

    private fun totalValue(data: ArrayList<Data>): Int {
        var totalValue = 0
        for (count in data) {
            if (count.id != "delayedTasks") {
                totalValue += count.count!!
            }
        }
        return totalValue
    }

    private fun totalPriority(data: ArrayList<Data>): Int {
        var totalValue = 0
        for (count in data) {
            totalValue += count.count!!
        }
        return totalValue
    }

    private fun getRatio(count: Float, totalValue: Int): Float {
        return (count / totalValue) * 100
    }

    private fun setPieChart(data: ArrayList<Data>) {
        val inProgress =
            (binding.txtProgressCount.text.toString().toFloat() / totalValue(data)) * 100
        val assigned = (binding.txtTasksCount.text.toString().toFloat() / totalValue(data)) * 100
        val complete = (binding.txtCompetedCount.text.toString().toFloat() / totalValue(data)) * 100

        val inProgressData = PieChartValues(inProgress.toString(), "#06CCF3")
        val assignedData = PieChartValues(assigned.toString(), "#E5E5E5")
        val completeData = PieChartValues(complete.toString(), "#004877")

        pieChartValues.add(inProgressData)
        pieChartValues.add(assignedData)
        pieChartValues.add(completeData)

        Log.d(
            TAG,
            "inProgress $inProgress\n assigned $assigned\n complete $complete\n pieChartValue $pieChartValues"
        )
        setPieChart(pieChartValues, binding.pieChart)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        pieChartValues.clear()
    }

    companion object {
        const val TAG = "HomeFragment"
    }
}