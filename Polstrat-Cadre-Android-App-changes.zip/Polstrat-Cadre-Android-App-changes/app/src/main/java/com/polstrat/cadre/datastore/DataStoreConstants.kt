package com.move.radianandroid.utils.datastore

import androidx.datastore.preferences.core.stringPreferencesKey

object DataStoreConstants {
    val CLIENT_ID = stringPreferencesKey("clientId")
    val CADRE_TOKEN = stringPreferencesKey("cadreToken")
    val FCM_TOKEN = stringPreferencesKey("fcmToken")
    val TOKEN = stringPreferencesKey("token")
    val F_NAME = stringPreferencesKey("fName")
    val L_NAME = stringPreferencesKey("lName")
    val ROLE = stringPreferencesKey("role")
    val EMAIL = stringPreferencesKey("email")
    val CONSTITUENCY_Id = stringPreferencesKey("constituencyId")
    val PROFILE_PIC = stringPreferencesKey("profilePic")
    val NOTIFICATION_RECEIVED = stringPreferencesKey("notificationReceived")

}