package com.polstrat.cadre.fragment

import android.app.Activity
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.IntentSender
import android.content.pm.ActivityInfo
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.content.res.AppCompatResources
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.Observer
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.navigation.Navigation
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.NavigationUI
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.navigation.NavigationBarView
import com.google.android.material.snackbar.Snackbar
import com.google.android.play.core.appupdate.AppUpdateInfo
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.install.InstallStateUpdatedListener
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.InstallStatus
import com.google.android.play.core.install.model.UpdateAvailability
import com.move.radianandroid.utils.datastore.DataStoreManager
import com.polstrat.cadre.R
import com.polstrat.cadre.databinding.ActivityHostBinding
import com.polstrat.cadre.modelClass.requestModel.FCMRequestModel
import com.polstrat.cadre.modelClass.responseModel.FCMResponseModel
import com.polstrat.cadre.networkClient.NetworkResult
import com.polstrat.cadre.utils.Constants.getLocalDeviceId
import com.polstrat.cadre.viewModels.MainViewModel
import com.polstrat.cadre.viewModels.ProfileViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.FlowCollector
import kotlinx.coroutines.launch

class HostActivity : AppCompatActivity() {

    private lateinit var hostBinding: ActivityHostBinding
    private lateinit var bottomNavigationView: BottomNavigationView
    private var navHostFragment: NavHostFragment? = null
    private val mainViewModel: MainViewModel by viewModels()
    private val profileViewModel: ProfileViewModel by viewModels()
    lateinit var profileMenuItem: MenuItem
    private var userId: String = ""
    private var fcmToken: String = ""
    private var cadreToken: String = ""
    private val appUpdateManager by lazy { AppUpdateManagerFactory.create(this) }
    private lateinit var installStateUpdatedListener: InstallStateUpdatedListener

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hostBinding = DataBindingUtil.setContentView(this, R.layout.activity_host)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        // Register the broadcast receiver
        val filter = IntentFilter("com.polstrat.cadre.sendNotificationBroadcast")
        LocalBroadcastManager.getInstance(this).registerReceiver(receiver, filter)
        setBottomNavigation()

        lifecycleScope.launchWhenStarted {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    mainViewModel.moveUIState.collect(uiStateCollector)
                }
                fcmToken = DataStoreManager(this@HostActivity).getFCMToken()
                userId = DataStoreManager(this@HostActivity).getClientId()
                cadreToken = DataStoreManager(this@HostActivity).getCadreToken()
                if (userId.isNotEmpty()) {
                    sendFCMToken()
                }
            }

        }

        mainViewModel.isProfileDeleted.observe(this) {
            if (it) {
                mainViewModel.isProfileDeleted.value = false
                profileMenuItem.icon =
                    AppCompatResources.getDrawable(this, R.drawable.profile_avatar)
            }
        }

        val notificationPermissionGranted = checkNotificationPermission()
        if (!notificationPermissionGranted) {
            showNotificationPermissionRationale()
        }
        updateChecker()
    }

    private suspend fun sendFCMToken() {
        Log.d(TAG, "deviceId: ${getLocalDeviceId(this)} \nuserId: $userId \nfcmToken: $fcmToken")
        val fcmRequest = FCMRequestModel(fcmToken, userId, getLocalDeviceId(this))
        mainViewModel.sendToken(
            fcmRequest,
            "Bearer $cadreToken"
        ).collect(statsCollector)
    }

    private val statsCollector: FlowCollector<NetworkResult<FCMResponseModel>> =
        FlowCollector { response ->
            when (response) {
                is NetworkResult.Loading -> {
                }

                is NetworkResult.Success -> {
                    response.data?.let {
                        Log.d(TAG, "$it")
                    }
                }

                is NetworkResult.Error -> {
                    Log.e(TAG, "response error ${response.message}")
                }
            }
        }

    private val uiStateCollector: FlowCollector<MainViewModel.PolstratUIState> =
        FlowCollector { uiState ->
            Log.d(TAG, "uiState $uiState")
            bottomNavigationView.menu.findItem(bottomNavigationView.selectedItemId).isCheckable =
                true
            // Set the profile picture as the icon for the menu item
            profileMenuItem = bottomNavigationView.menu.findItem(R.id.profileFragment)
            loadProfileAsIcon()
            profileViewModel.profilePic.observe(this, profilePicObserver)

            val states = arrayOf(
                intArrayOf(android.R.attr.state_selected), // enabled
                intArrayOf(-android.R.attr.state_selected), // disabled
            )
            val colors = intArrayOf(

                ContextCompat.getColor(this, R.color.button_color),
                ContextCompat.getColor(this, R.color.unselected_tab)
            )
            val myList = ColorStateList(states, colors)
            bottomNavigationView.itemTextColor = myList

            when (uiState) {
                is MainViewModel.PolstratUIState.HomeScreen -> {
                    Navigation.findNavController(this, R.id.nav_host_fragment)
                        .navigate(R.id.homeFragment)
                }

                is MainViewModel.PolstratUIState.MyTasksScreen -> {
                    Navigation.findNavController(this, R.id.nav_host_fragment)
                        .navigate(R.id.taskFragment)
                }

                is MainViewModel.PolstratUIState.FormScreen -> {
                    Navigation.findNavController(this, R.id.nav_host_fragment)
                        .navigate(R.id.formFragment)
                }

                is MainViewModel.PolstratUIState.ProfileScreen -> {
                    Navigation.findNavController(this, R.id.nav_host_fragment)
                        .navigate(R.id.profileFragment)
                }

                is MainViewModel.PolstratUIState.Empty -> {
                    //doNothing
                }

            }
            mainViewModel.saveSelectedBottomMenuId(bottomNavigationView.selectedItemId)

        }

    private val profilePicObserver = Observer<String> {
        Glide.with(this)
            .asBitmap()
            .load(it)
            .apply(RequestOptions.circleCropTransform())
            .into(object : CustomTarget<Bitmap>() {
                override fun onResourceReady(
                    resource: Bitmap,
                    transition: Transition<in Bitmap>?
                ) {
                    // Convert Bitmap to Drawable
                    val profileDrawable = BitmapDrawable(resources, resource)
                    profileMenuItem.icon = profileDrawable
                }

                override fun onLoadCleared(placeholder: Drawable?) {
                    // Optional: handle when the image is cleared
                }
            })
    }

    private suspend fun loadProfileAsIcon() {
        if (DataStoreManager(this).getProfilePic().isNotEmpty()) {
            Glide.with(this)
                .asBitmap()
                .load(DataStoreManager(this).getProfilePic())
                .apply(RequestOptions.circleCropTransform())
                .into(object : CustomTarget<Bitmap>() {
                    override fun onResourceReady(
                        resource: Bitmap,
                        transition: Transition<in Bitmap>?
                    ) {
                        // Convert Bitmap to Drawable
                        val profileDrawable = BitmapDrawable(resources, resource)
                        profileMenuItem.icon = profileDrawable
                    }

                    override fun onLoadCleared(placeholder: Drawable?) {
                        // Optional: handle when the image is cleared
                    }
                })
        } else {
            profileMenuItem.icon =
                AppCompatResources.getDrawable(this, R.drawable.profile_avatar)
        }
    }

    override fun onPause() {
        super.onPause()
        mainViewModel.updateUIState(MainViewModel.PolstratUIState.Empty)
    }

    private fun setUpNavigation() {
        bottomNavigationView = findViewById<View>(R.id.bottom_nav_view) as BottomNavigationView
        navHostFragment =
            (supportFragmentManager.findFragmentById(R.id.nav_host_fragment) as NavHostFragment?)
        bottomNavigationView.itemIconTintList = null
    }

    private fun setBottomNavigation() {
        setUpNavigation()
        val parent =
            findViewById<View>(R.id.lyt_parent_bottom_nav) as CoordinatorLayout
        parent.visibility = View.VISIBLE
        bottomNavigationView.background = null

        val inflater = navHostFragment?.navController?.navInflater
        val graph = inflater?.inflate(R.navigation.nav_graph)
        if (graph != null) {
            navHostFragment?.navController?.graph = graph
        }

        bottomNavigationView.setOnItemSelectedListener(bottomNavigationItemListener)
        NavigationUI.setupWithNavController(
            bottomNavigationView, navHostFragment?.navController!!
        )

    }

    private val bottomNavigationItemListener = NavigationBarView.OnItemSelectedListener { item ->
        when (item.itemId) {

            R.id.homeFragment -> {
                mainViewModel.updateUIState(MainViewModel.PolstratUIState.HomeScreen)
            }

            R.id.taskFragment -> {
                mainViewModel.updateUIState(MainViewModel.PolstratUIState.MyTasksScreen)
            }

            R.id.formFragment -> {
                mainViewModel.updateUIState(MainViewModel.PolstratUIState.FormScreen)
            }

            R.id.profileFragment -> {
                mainViewModel.updateUIState(MainViewModel.PolstratUIState.ProfileScreen)
            }
        }
        true
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        val actionType = intent?.getStringExtra("source")
        Log.d(TAG, "actionPerformed $actionType")
        if (actionType.equals("true")) {
            mainViewModel.redirectToNotif.postValue(actionType)
        }
    }

    private fun checkNotificationPermission(): Boolean {
        val notificationManager =
            this.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        return notificationManager.areNotificationsEnabled()
    }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (!isGranted) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    showSettingDialog()
                }
            } else {
                Toast.makeText(
                    applicationContext,
                    "Permission granted",
                    Toast.LENGTH_SHORT
                )
                    .show()
            }
        }

    private fun showSettingDialog() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            var intent: Intent
            MaterialAlertDialogBuilder(
                this,
                com.google.android.material.R.style.MaterialAlertDialog_Material3
            )
                .setTitle("Notification Permission")
                .setMessage("Notification permission is required, Please allow notification permission from setting")
                .setPositiveButton("Go to setting") { _, _ ->
                    intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    intent.putExtra(Settings.EXTRA_APP_PACKAGE, this.packageName)
                    startActivity(intent)
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

    }

    private fun showNotificationPermissionRationale() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            MaterialAlertDialogBuilder(
                this,
                com.google.android.material.R.style.MaterialAlertDialog_Material3
            )
                .setTitle("Alert")
                .setMessage("Notification permission is required, to receive the notifications")
                .setPositiveButton("Enable") { _, _ ->
                    notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                }
                .setNegativeButton("Cancel") { _, _ ->
                    Toast.makeText(this, "", Toast.LENGTH_SHORT).show()
                }
                .show()
        }
    }

    private fun updateChecker() {
        // Initialize the listener for install state updates
        installStateUpdatedListener = InstallStateUpdatedListener { installState ->
            if (installState.installStatus() == InstallStatus.DOWNLOADED) {
                // Inform the user that the update has been downloaded and needs installation
                showCompleteUpdateConfirmation()
            }
        }

        // Register the listener to monitor install state changes
        appUpdateManager.registerListener(installStateUpdatedListener)

        // Check for updates as soon as the app starts
        checkForUpdates()
    }

    override fun onDestroy() {
        super.onDestroy()
        LocalBroadcastManager.getInstance(this).unregisterReceiver(receiver)
        // Unregister the listener when the activity is destroyed to prevent memory leaks
        appUpdateManager.unregisterListener(installStateUpdatedListener)
    }

    private fun checkForUpdates() {
        val appUpdateInfoTask = appUpdateManager.appUpdateInfo
        appUpdateInfoTask.addOnSuccessListener { appUpdateInfo ->
            if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE &&
                appUpdateInfo.isUpdateTypeAllowed(AppUpdateType.FLEXIBLE)
            ) {
                // Request the update if an update is available and flexible updates are allowed
                requestUpdate(appUpdateInfo)
            }
        }
    }

    private fun requestUpdate(appUpdateInfo: AppUpdateInfo) {
        try {
            appUpdateManager.startUpdateFlowForResult(
                appUpdateInfo,
                AppUpdateType.FLEXIBLE,
                this,
                REQUEST_UPDATE
            )
        } catch (e: IntentSender.SendIntentException) {
            e.printStackTrace()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_UPDATE) {
            if (resultCode != Activity.RESULT_OK) {
                // If the user cancels the update, handle it here
                Toast.makeText(this, "Update canceled", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showCompleteUpdateConfirmation() {
        // Inform the user that the update has been downloaded and needs installation
        // You can prompt the user to install the update or do it later
        val rootView = findViewById<ConstraintLayout>(R.id.lytHostMain)
        val snackbar = Snackbar.make(
            rootView,
            "A new update has been downloaded and is ready to install.",
            Snackbar.LENGTH_INDEFINITE
        )
        snackbar.setAction("Install") {
            // Start the update installation process
            appUpdateManager.completeUpdate()
        }
        snackbar.setActionTextColor(ContextCompat.getColor(this, R.color.unselected_tab))
        snackbar.show()
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == "com.polstrat.cadre.sendNotificationBroadcast") {
                val data = intent.getStringExtra("isReceived")
                Log.d(TAG, "Notification received: $data")
                CoroutineScope(Dispatchers.Main).launch {
                    DataStoreManager(this@HostActivity).saveNotificationReceived(data.toString())
                }
                mainViewModel.isNotificationReceived.value = data
            }
        }
    }//
    companion object {
        const val TAG = "HostActivity"
        private const val REQUEST_UPDATE = 1001
    }

}