package com.polstrat.cadre.modelClass.responseModel

import com.google.gson.annotations.SerializedName

data class UserProfileResponseModel(
    val data: DataDetails? = null,
    val error: Any? = null,
    val message: String? = null,
    val status: Boolean? = false
)

data class DataDetails(
    @SerializedName("_id")
    val id: String? = null,
    val clientPassword: String? = null,
    val constituencyId: String? = null,
    val constituencyName: String? = null,
    val email: String? = null,
    val firstName: String? = null,
    val lastName: String? = null,
    val officeId: String? = null,
    val officeName: String? = null,
    val organisationId: String? = null,
    val phone: Long? = null,
    val reportsTo: String? = null,
    val reporting: String? = null,
    val role: String? = null,
    val status: String? = null
)