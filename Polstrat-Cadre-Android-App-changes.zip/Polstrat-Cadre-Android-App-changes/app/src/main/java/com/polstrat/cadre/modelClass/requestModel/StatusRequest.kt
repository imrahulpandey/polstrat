package com.polstrat.cadre.modelClass.requestModel

data class StatusRequest(
    val status: String
)

data class UpdateStatusRequest(
    val status: String,
    val postCompletionImages: List<UploadImage>
)
