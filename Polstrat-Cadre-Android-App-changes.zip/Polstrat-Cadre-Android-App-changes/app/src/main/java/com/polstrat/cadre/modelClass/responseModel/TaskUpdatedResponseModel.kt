package com.polstrat.cadre.modelClass.responseModel

data class TaskUpdatedResponseModel(
    val data: UserTasks,
    val error: Any,
    val message: String,
    val status: Boolean
)