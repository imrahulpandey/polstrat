package com.polstrat.cadre.modelClass.responseModel

import com.google.gson.annotations.SerializedName

data class UniversalResponse(
    @SerializedName("data")
    val data: UsersData? = null,
    val error: Any? = null,
    val message: String? = null,
    val status: Boolean = false
)

data class UsersData(
    @SerializedName("clientUser")
    val clientUser: ClientUsers? = null,
    val token: String? = null
)

data class ClientUsers(
    @SerializedName("_id")
    val id: String? = null,
    val cadreToken: String? = null,
    val constituencyId: String? = null,
    val constituencyName: String? = null,
    val email: String? = null,
    val firstName: String? = null,
    val lastName: String? = null,
    val officeId: String? = null,
    val officeLocation: String? = null,
    val profileImageLink: String? = null,
    val officeName: String? = null,
    val organisationId: String? = null,
    val phone: Long? = null,
    val reportingTo: String? = null,
    val role: String? = null,
    val status: String? = null,
    val subscription: List<Subscription>? = null,
    val type: String? = null
)

data class Subscription(
    @SerializedName("_id")
    val id: String,
    val name: String
)