package com.polstrat.cadre.modelClass.responseModel

data class ProfilePicResponseModel(
    val data: UpdatedData,
    val error: Any,
    val message: String,
    val status: Boolean
)

data class UpdatedData(
    val email: String,
    val firstName: String,
    val id: String,
    val lastName: String,
    val profileImageLink: ProfileImageLink
)

data class ProfileImageLink(
    val key: String,
    val name: String,
    val publicUrl: String
)