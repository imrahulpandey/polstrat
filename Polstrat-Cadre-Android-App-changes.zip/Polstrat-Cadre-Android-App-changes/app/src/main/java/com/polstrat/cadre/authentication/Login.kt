package com.polstrat.cadre.authentication

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import androidx.core.widget.addTextChangedListener
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.lifecycleScope
import com.polstrat.cadre.R
import com.polstrat.cadre.databinding.ActivityLoginBinding
import com.polstrat.cadre.modelClass.responseModel.UniversalResponse
import com.polstrat.cadre.networkClient.NetworkResult
import com.polstrat.cadre.utils.BaseActivity
import com.polstrat.cadre.utils.Constants.MOB_NUMBER
import com.polstrat.cadre.utils.Constants.hideKeyboard
import com.polstrat.cadre.utils.LoaderDialog
import com.polstrat.cadre.utils.Spec
import com.polstrat.cadre.viewModels.LoginViewModel
import kotlinx.coroutines.flow.FlowCollector

class Login : BaseActivity(), Spec {

    private lateinit var binding: ActivityLoginBinding
    private var loginViewModel: LoginViewModel? = null
    private var mobileNumber: String? = null
    private lateinit var loaderDialog: LoaderDialog

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_login)
        setUpResources()
    }

    override fun setUpResources() {
        binding.apply {
            presenter = this@Login
            lifecycleOwner = this@Login
            executePendingBindings()
        }
        loginViewModel = LoginViewModel(application)
        loaderDialog = LoaderDialog(this)

        binding.edtMobNum.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                //write your login
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                //write your login
            }

            override fun afterTextChanged(s: Editable?) {
                // Check if the input length reaches 10 digits
                if (s?.length == 10) {
                    // If 10 digits entered, hide the keyboard
                    hideKeyboard(this@Login, binding.edtMobNum)
                }
            }
        })
    }


    override fun onDestroy() {
        super.onDestroy()
        shutDown()
    }

    override fun shutDown() {
        loginViewModel?.releaseViewModel()
    }


    fun getOTP() {
        mobileNumber = binding.edtMobNum.text.toString()
        Log.d(TAG, "$mobileNumber")
        lifecycleScope.launchWhenStarted {
            if (mobileNumber?.let { validatePhoneNumber(it) } == true) {
                loginViewModel?.sendOTP(
                    binding.edtMobNum.text.toString()
                )?.collect(statsCollector)
            } else {
                showToastShort(this@Login, "Invalid mobile number")
            }
        }

    }

    private val statsCollector: FlowCollector<NetworkResult<UniversalResponse>> =
        FlowCollector { response ->
            when (response) {
                is NetworkResult.Loading -> {
                    loaderDialog.show()
                }

                is NetworkResult.Success -> {
                    response.data?.let {
                        loaderDialog.dismiss()
                        it.message?.let { it1 -> showToastShort(this, it1) }
                        if (it.status) {
                            val intent = Intent(this@Login, OTPVerification::class.java)
                            intent.putExtra(MOB_NUMBER, mobileNumber)
                            startActivity(intent)
                            finish()
                        }
                    }
                }

                is NetworkResult.Error -> {
                    Log.e(TAG, "response error ${response.message}")
                    loaderDialog.dismiss()
                    showToastShort(this, response.message)
                }
            }
        }

    companion object {
        const val TAG = "LoginActivity"
    }
}