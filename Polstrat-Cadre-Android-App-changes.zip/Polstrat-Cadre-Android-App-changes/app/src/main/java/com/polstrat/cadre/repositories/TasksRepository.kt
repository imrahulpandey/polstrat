package com.polstrat.cadre.repositories

import android.app.Application
import androidx.paging.Pager
import androidx.paging.PagingConfig
import com.polstrat.cadre.adapterClass.TaskPagingSource
import com.polstrat.cadre.modelClass.requestModel.StatusRequest
import com.polstrat.cadre.modelClass.responseModel.TasksFiltersResponseModel
import com.polstrat.cadre.networkClient.NetworkResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn

class TasksRepository(application: Application) : BaseRepository(application) {

    fun getAllTasks(token: String, statusRequest: StatusRequest) = Pager(
        pagingSourceFactory = { TaskPagingSource(retrofitInterface, token, statusRequest) },
        config = PagingConfig(pageSize = 10)
    ).flow

    suspend fun getTasksByKeywords(
        status: String,
        keywords: String,
        token: String
    ): Flow<NetworkResult<TasksFiltersResponseModel>> {
        return flow {
            try {
                emit(NetworkResult.Loading())
                val response = retrofitInterface.getFilteredTasksByKeywords(status, keywords, token)
                if (response.isSuccessful && response.body() != null) {
                    emit(NetworkResult.Success(response.body()))
                } else {
                    emit(NetworkResult.Error(response.message()))
                }
            } catch (e: Exception) {
                emit(NetworkResult.Error(e.message.toString()))
            }
        }.flowOn(Dispatchers.IO)
    }
}