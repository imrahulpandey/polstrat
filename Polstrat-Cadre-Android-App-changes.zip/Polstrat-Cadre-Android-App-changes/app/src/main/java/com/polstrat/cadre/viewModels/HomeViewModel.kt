package com.polstrat.cadre.viewModels

import android.app.Application
import com.polstrat.cadre.modelClass.responseModel.TaskResponseModel
import com.polstrat.cadre.networkClient.NetworkResult
import com.polstrat.cadre.repositories.HomeRepository
import kotlinx.coroutines.flow.Flow

class HomeViewModel(application: Application) : BaseViewModel(application) {

    private var homeRepository: HomeRepository =
        HomeRepository(application)

    suspend fun getHomeGraphData(
        token: String
    ): Flow<NetworkResult<TaskResponseModel>> {
        return homeRepository.getHomeGraphData(token)
    }

    suspend fun getHomePriorityData(
        token: String
    ): Flow<NetworkResult<TaskResponseModel>> {
        return homeRepository.getHomePriorityData(token)
    }

}