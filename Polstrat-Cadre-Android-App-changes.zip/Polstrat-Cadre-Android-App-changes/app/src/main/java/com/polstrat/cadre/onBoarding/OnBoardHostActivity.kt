package com.polstrat.cadre.onBoarding

import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.viewpager2.widget.ViewPager2
import com.polstrat.cadre.R
import com.polstrat.cadre.adapterClass.ViewPagerAdapterClass
import com.polstrat.cadre.authentication.Login
import com.polstrat.cadre.databinding.ActivityOnBoardHostBinding
import com.polstrat.cadre.modelClass.responseModel.ViewPagerModel

class OnBoardHostActivity : AppCompatActivity() {

    private lateinit var binding: ActivityOnBoardHostBinding
    private lateinit var viewPagerItem: ArrayList<ViewPagerModel>
    private lateinit var viewPagerAdapter: ViewPagerAdapterClass
    var selectedPosition: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_on_board_host)
        binding.apply {
            presenter = this@OnBoardHostActivity
            lifecycleOwner = this@OnBoardHostActivity
            executePendingBindings()
        }

        viewPagerItem = ArrayList()

        val illustratorList = arrayOf(
            R.drawable.onboard_illustrator_1,
            R.drawable.onboard_illustrator_2,
            R.drawable.onboard_illustrator_3
        )
        val titleList = arrayOf(
            getString(R.string.grievances_tasks),
            getString(R.string.view_info_location),
            getString(R.string.mark_complete)
        )
        val descriptionList = arrayOf(
            getString(R.string.dummy_text_long),
            getString(R.string.dummy_text_long),
            getString(R.string.dummy_text_long)
        )

        for (index in illustratorList.indices) {
            viewPagerItem.add(
                ViewPagerModel(
                    illustratorList[index],
                    titleList[index],
                    ""
                )
            )
        }

        viewPagerAdapter = ViewPagerAdapterClass(viewPagerItem)
        binding.viewPager.adapter = viewPagerAdapter
        binding.viewPager.clipToPadding = false
        binding.viewPager.clipChildren = false
        binding.viewPager.getChildAt(0).overScrollMode = View.OVER_SCROLL_NEVER

        binding.viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                selectedPosition = position
                when (position) {
                    0 -> {
                        val progressAnimator = ObjectAnimator.ofInt(
                            binding.progressBar,
                            "progress",
                            binding.progressBar.progress,
                            0
                        )
                        progressAnimator.duration = 1000
                        progressAnimator.start()
                        binding.progressBar.progress = 0
                        binding.dotOne.setImageResource(R.drawable.active_dot)
                        binding.dotTwo.setImageResource(R.drawable.inactive_dot)
                        binding.dotThree.setImageResource(R.drawable.inactive_dot)
                        binding.btnNext.setImageResource(R.drawable.next_active_ic)
                    }

                    1 -> {
                        val progressAnimator = ObjectAnimator.ofInt(
                            binding.progressBar,
                            "progress",
                            binding.progressBar.progress,
                            50
                        )
                        progressAnimator.duration = 1000
                        progressAnimator.start()
                        binding.progressBar.progress = 50
                        binding.dotOne.setImageResource(R.drawable.inactive_dot)
                        binding.dotTwo.setImageResource(R.drawable.active_dot)
                        binding.dotThree.setImageResource(R.drawable.inactive_dot)
                        binding.btnNext.setImageResource(R.drawable.next_active_ic)
                    }

                    2 -> {
                        binding.progressBar.progress = 100
                        val progressAnimator =
                            ObjectAnimator.ofInt(binding.progressBar, "progress", 50, 100)
                        progressAnimator.duration = 1000
                        progressAnimator.start()
                        binding.dotOne.setImageResource(R.drawable.inactive_dot)
                        binding.dotTwo.setImageResource(R.drawable.inactive_dot)
                        binding.dotThree.setImageResource(R.drawable.active_dot)
                        binding.btnNext.setImageResource(R.drawable.verified_sign)
                    }
                }
            }
        })
    }

    private fun goToLogin() {
        startActivity(Intent(this, Login::class.java))
        finish()
    }

    fun skip() {
        goToLogin()
    }

    fun next() {
        val nextPosition = selectedPosition + 1
        if (nextPosition < (binding.viewPager.adapter?.itemCount ?: 0)) {
            binding.viewPager.currentItem = nextPosition
        } else {
            // Redirect to login page
            goToLogin()
        }
    }

}