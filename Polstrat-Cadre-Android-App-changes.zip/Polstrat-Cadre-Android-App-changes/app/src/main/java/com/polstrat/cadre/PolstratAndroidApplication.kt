package com.polstrat.cadre

import android.app.Application
import android.content.Context
import androidx.appcompat.app.AppCompatDelegate

class PolstratAndroidApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        appContext = applicationContext
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
    }

    companion object {
        private var appInstance: PolstratAndroidApplication? = null
        lateinit var appContext: Context
            private set

        val instance: PolstratAndroidApplication?
            get() {
                if (appInstance == null) {
                    appInstance = PolstratAndroidApplication()
                }
                return appInstance
            }
    }

}