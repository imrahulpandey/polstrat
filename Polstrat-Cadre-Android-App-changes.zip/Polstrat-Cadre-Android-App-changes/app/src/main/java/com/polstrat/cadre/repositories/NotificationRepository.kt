package com.polstrat.cadre.repositories

import android.app.Application
import androidx.paging.Pager
import androidx.paging.PagingConfig
import com.polstrat.cadre.adapterClass.NotificationPagingSource
import com.polstrat.cadre.modelClass.requestModel.IssueReportRequest
import com.polstrat.cadre.modelClass.responseModel.NotificationMarkedReadResponse
import com.polstrat.cadre.modelClass.responseModel.ReportedIssueModelResponse
import com.polstrat.cadre.networkClient.NetworkResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn

class NotificationRepository(application: Application) : BaseRepository(application) {

    fun getNotificationsList(token: String) = Pager(
        pagingSourceFactory = { NotificationPagingSource(retrofitInterface, token) },
        config = PagingConfig(pageSize = 10)
    ).flow

    suspend fun markAsReadAll(
        token: String
    ): Flow<NetworkResult<NotificationMarkedReadResponse>> {
        return flow {
            try {
                emit(NetworkResult.Loading())
                val response = retrofitInterface.markAsReadAll(token)
                if (response.isSuccessful && response.body() != null) {
                    emit(NetworkResult.Success(response.body()))
                } else {
                    emit(NetworkResult.Error(response.message()))
                }
            } catch (e: Exception) {
                emit(NetworkResult.Error(e.message.toString()))
            }
        }.flowOn(Dispatchers.IO)

    }
}