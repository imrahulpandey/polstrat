package com.polstrat.cadre.viewModels

import android.app.Application
import androidx.lifecycle.MutableLiveData
import com.polstrat.cadre.modelClass.Categories
import com.polstrat.cadre.modelClass.requestModel.FormRequestModel
import com.polstrat.cadre.modelClass.requestModel.IssueReportRequest
import com.polstrat.cadre.modelClass.requestModel.UploadImage
import com.polstrat.cadre.modelClass.responseModel.FormResponseModel
import com.polstrat.cadre.modelClass.responseModel.ReportedIssueModelResponse
import com.polstrat.cadre.networkClient.NetworkResult
import com.polstrat.cadre.repositories.FormRepository
import kotlinx.coroutines.flow.Flow

class FormViewModel(
    application: Application
) : BaseViewModel(application) {

    private var formRepository: FormRepository =
        FormRepository(application)

    var lat = MutableLiveData<String>()
    var lon = MutableLiveData<String>()
    var addr = MutableLiveData<String>()

    var imageUrl: MutableList<UploadImage> = mutableListOf()
    var priority: String = ""

    suspend fun createForm(
        formRequestModel: FormRequestModel,
        token: String
    ): Flow<NetworkResult<FormResponseModel>> {
        return formRepository.createForm(formRequestModel, token)
    }

    suspend fun getCategories(
        token: String
    ): Flow<NetworkResult<Categories>> {
        return formRepository.getCategories(token)
    }

    suspend fun getSubCategories(
        parentId: String,
        token: String
    ): Flow<NetworkResult<Categories>> {
        return formRepository.getSubCategories(parentId, token)
    }

    suspend fun raiseTickets(
        issueReportRequest: IssueReportRequest,
        token: String
    ): Flow<NetworkResult<ReportedIssueModelResponse>> {
        return formRepository.raiseTickets(issueReportRequest, token)
    }
}