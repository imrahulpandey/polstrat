package com.polstrat.cadre.repositories

import android.app.Application
import com.polstrat.cadre.modelClass.responseModel.TaskResponseModel
import com.polstrat.cadre.networkClient.NetworkResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn

class HomeRepository(application: Application) : BaseRepository(application) {

    suspend fun getHomeGraphData(token: String): Flow<NetworkResult<TaskResponseModel>> {
        return flow {
            try {
                emit(NetworkResult.Loading())
                val response = retrofitInterface.getHomeGraphData(token)
                if (response.isSuccessful && response.body() != null) {
                    emit(NetworkResult.Success(response.body()))
                } else {
                    emit(NetworkResult.Error(response.message()))
                }
            } catch (e: Exception) {
                emit(NetworkResult.Error(e.message.toString()))
            }
        }.flowOn(Dispatchers.IO)

    }

    suspend fun getHomePriorityData(token: String): Flow<NetworkResult<TaskResponseModel>> {
        return flow {
            try {
                emit(NetworkResult.Loading())
                val response = retrofitInterface.getHomePriorityData(token)
                if (response.isSuccessful && response.body() != null) {
                    emit(NetworkResult.Success(response.body()))
                } else {
                    emit(NetworkResult.Error(response.message()))
                }
            } catch (e: Exception) {
                emit(NetworkResult.Error(e.message.toString()))
            }
        }.flowOn(Dispatchers.IO)

    }
}