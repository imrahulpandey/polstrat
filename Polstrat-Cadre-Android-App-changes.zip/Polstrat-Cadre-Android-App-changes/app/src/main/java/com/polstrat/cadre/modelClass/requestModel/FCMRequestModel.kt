package com.polstrat.cadre.modelClass.requestModel

data class FCMRequestModel(
    val fcmToken: String? = null,
    val clientId: String? = null,
    val deviceId: String? = null
)
