package com.polstrat.cadre.modelClass.responseModel

import com.google.gson.annotations.SerializedName

data class FCMResponseModel(
    val data: FCMData,
    val error: Any,
    val message: String,
    val status: Boolean
)

data class FCMData(
    val fcm: Fcm
)

data class Fcm(
    @SerializedName("__v")
    val v: Int,
    @SerializedName("_id")
    val id: String,
    val clientId: String,
    val createdAt: String,
    val deviceId: String,
    val fcmToken: String,
    val isValid: Boolean,
    val updatedAt: String
)