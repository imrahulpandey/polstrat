package com.polstrat.cadre.diffUtils

import androidx.recyclerview.widget.DiffUtil
import com.polstrat.cadre.modelClass.responseModel.UserTasks

class TaskDiffUtilClass: DiffUtil.ItemCallback<UserTasks>() {
    override fun areItemsTheSame(oldItem: UserTasks, newItem: UserTasks): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: UserTasks, newItem: UserTasks): Boolean {
        return oldItem == newItem
    }
}