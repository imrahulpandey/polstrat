package com.polstrat.cadre.fragment

import android.graphics.Typeface
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import androidx.appcompat.content.res.AppCompatResources
import androidx.appcompat.widget.SearchView
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.paging.LoadState
import com.move.radianandroid.utils.datastore.DataStoreManager
import com.polstrat.cadre.R
import com.polstrat.cadre.adapterClass.PaginationLoaderAdapter
import com.polstrat.cadre.adapterClass.TaskListAdapter
import com.polstrat.cadre.adapterClass.TasksListAdapter
import com.polstrat.cadre.databinding.FragmentTasksBinding
import com.polstrat.cadre.modelClass.requestModel.StatusRequest
import com.polstrat.cadre.modelClass.responseModel.TasksFiltersResponseModel
import com.polstrat.cadre.modelClass.responseModel.UserTasks
import com.polstrat.cadre.networkClient.NetworkResult
import com.polstrat.cadre.utils.BaseFragment
import com.polstrat.cadre.utils.Constants
import com.polstrat.cadre.utils.Spec
import com.polstrat.cadre.viewModels.FormViewModel
import com.polstrat.cadre.viewModels.MainViewModel
import com.polstrat.cadre.viewModels.TasksViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.FlowCollector
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

class TasksFragment : BaseFragment(), Spec {

    lateinit var binding: FragmentTasksBinding
    private val tasksViewModel: TasksViewModel by activityViewModels()
    private val formViewModel: FormViewModel by activityViewModels()
    private val mainViewModel: MainViewModel by activityViewModels()
    private lateinit var tasksListAdapter: TasksListAdapter
    private lateinit var taskListAdapter: TaskListAdapter
    private var statusRequest: StatusRequest? = null
    private var currentStatus = "inProgress"
    private var searchKeyword = ""

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = DataBindingUtil.inflate(layoutInflater, R.layout.fragment_tasks, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.apply {
            presenter = this@TasksFragment
            lifecycleOwner = this@TasksFragment
            executePendingBindings()
        }
        setUpResources()

        CoroutineScope(Dispatchers.Default).launch {
            if (DataStoreManager(requireContext()).getNotificationReceived() == "true") {
                binding.Notification.setImageResource(R.drawable.unread_notification_ic)
            } else {
                binding.Notification.setImageResource(R.drawable.read_notification_ic)
            }
        }
        mainViewModel.isNotificationReceived.observe(viewLifecycleOwner) {
            if (it.equals("true")) {
                binding.Notification.setImageResource(R.drawable.unread_notification_ic)
            } else {
                binding.Notification.setImageResource(R.drawable.read_notification_ic)
            }
        }

        mainViewModel.redirectToNotif.observe(viewLifecycleOwner) {
            if (it.equals("true")) {
                openNotification()
            }
        }
    }

    fun onClickTasksTab(userDataList: UserTasks) {
        tasksViewModel.getUserTaskData().value = userDataList
        if (isAdded && findNavController().currentDestination?.label == getString(R.string.task_fragment_label)) {
            lifecycleScope.launchWhenResumed {
                findNavController().navigate(R.id.action_taskFragment_to_taskDetailsFragment)
            }
        }
    }

    fun openNotification() {
        if (isAdded && findNavController().currentDestination?.label == getString(R.string.task_fragment_label)) {
            lifecycleScope.launchWhenResumed {
                findNavController().navigate(R.id.action_taskFragment_to_notificationFragment)
            }
        }
    }

    fun inProgress() {
        emptySearch()
        inProgressTab()
    }

    private fun inProgressTab() {
        currentStatus = Constants.IN_PROGRESS
        binding.apply {
            InProgress.background = AppCompatResources.getDrawable(
                requireContext(),
                R.drawable.selected_button_background
            )
            InProgress.setTextColor(resources.getColor(R.color.button_color))
            InProgress.setTypeface(null, Typeface.BOLD)
            NewTasks.background = AppCompatResources.getDrawable(
                requireContext(),
                R.drawable.un_selected_button_background
            )
            NewTasks.setTextColor(resources.getColor(R.color.white))
            NewTasks.setTypeface(null, Typeface.NORMAL)
            Complete.background = AppCompatResources.getDrawable(
                requireContext(),
                R.drawable.un_selected_button_background
            )
            Complete.setTextColor(resources.getColor(R.color.white))
            Complete.setTypeface(null, Typeface.NORMAL)
        }
        if (searchKeyword.isEmpty()) {
            callTaskCollector(currentStatus)
        } else {
            searchResult(searchKeyword)
        }
    }

    fun newTasks() {
        emptySearch()
        newTasksTab()
    }

    private fun newTasksTab() {
        currentStatus = Constants.ASSIGNED
        binding.apply {
            InProgress.background = AppCompatResources.getDrawable(
                requireContext(),
                R.drawable.un_selected_button_background
            )
            InProgress.setTextColor(resources.getColor(R.color.white))
            InProgress.setTypeface(null, Typeface.NORMAL)
            NewTasks.background = AppCompatResources.getDrawable(
                requireContext(),
                R.drawable.selected_button_background
            )
            NewTasks.setTextColor(resources.getColor(R.color.button_color))
            NewTasks.setTypeface(null, Typeface.BOLD)
            Complete.background = AppCompatResources.getDrawable(
                requireContext(),
                R.drawable.un_selected_button_background
            )
            Complete.setTextColor(resources.getColor(R.color.white))
            Complete.setTypeface(null, Typeface.NORMAL)
        }
        if (searchKeyword.isEmpty()) {
            callTaskCollector(currentStatus)
        } else {
            searchResult(searchKeyword)
        }
    }

    fun complete() {
        emptySearch()
        completeTab()
    }

    private fun completeTab() {
        currentStatus = Constants.COMPLETE
        binding.apply {
            InProgress.background = AppCompatResources.getDrawable(
                requireContext(),
                R.drawable.un_selected_button_background
            )
            InProgress.setTextColor(resources.getColor(R.color.white))
            InProgress.setTypeface(null, Typeface.NORMAL)
            NewTasks.background = AppCompatResources.getDrawable(
                requireContext(),
                R.drawable.un_selected_button_background
            )
            NewTasks.setTextColor(resources.getColor(R.color.white))
            NewTasks.setTypeface(null, Typeface.NORMAL)
            Complete.background = AppCompatResources.getDrawable(
                requireContext(),
                R.drawable.selected_button_background
            )
            Complete.setTextColor(resources.getColor(R.color.button_color))
            Complete.setTypeface(null, Typeface.BOLD)
        }
        if (searchKeyword.isEmpty()) {
            callTaskCollector(currentStatus)
        } else {
            searchResult(searchKeyword)
        }
    }

    private fun emptySearch() {
        binding.searchBar.setQuery("", false)
        searchKeyword = ""
    }

    override fun setUpResources() {
        setBottomNavVisibility(View.VISIBLE)
        formViewModel.priority = ""
        formViewModel.imageUrl.clear()
        binding.apply {
            runBlocking {
                launch {
                    Username.text =
                        "${DataStoreManager(requireContext()).getFName()} ${
                            DataStoreManager(
                                requireContext()
                            ).getLName()
                        }"

                    if (DataStoreManager(requireContext()).getRole() == "cadre") {
                        Position.text = "Cadre"
                    } else if (DataStoreManager(requireContext()).getRole() == "data_entry_operator") {
                        Position.text = "Data Entry Operator"
                    }
                }
            }
        }
        tasksListAdapter = TasksListAdapter(this@TasksFragment)
        taskListAdapter = TaskListAdapter(this@TasksFragment)

        binding.searchLayout.setOnClickListener {
            binding.searchBar.isIconified = false
        }

        binding.searchBar.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                // Called when the user submits the query (by pressing the "Search" button on the keyboard)
                searchKeyword = query
                searchResult(searchKeyword)
                return true
            }

            override fun onQueryTextChange(newText: String): Boolean {
                // Called when the text in the search view changes
                // You can use this to implement real-time search suggestions
                return false
            }
        })

        binding.searchBar.setOnCloseListener {
            binding.searchBar.setQuery("", true)
            callTaskCollector(currentStatus)
            return@setOnCloseListener true
        }
    }

    override fun onResume() {
        super.onResume()
        when (currentStatus) {
            Constants.IN_PROGRESS -> inProgressTab()
            Constants.ASSIGNED -> newTasksTab()
            Constants.COMPLETE -> completeTab()
        }
    }

    private fun callTaskCollector(status: String) {
        statusRequest = StatusRequest(status)
        viewLifecycleOwner.lifecycleScope.launchWhenCreated {
            tasksViewModel.getAllTasks(
                "Bearer ${DataStoreManager(requireContext()).getCadreToken()}",
                statusRequest!!
            ).collect { pagingData ->
                binding.rvTasks.adapter = tasksListAdapter.withLoadStateHeaderAndFooter(
                    header = PaginationLoaderAdapter(),
                    footer = PaginationLoaderAdapter()
                )
                tasksListAdapter.submitData(pagingData)
            }
        }
        tasksListAdapter.addLoadStateListener { loadState ->
            val isEmpty =
                loadState.refresh is LoadState.NotLoading && tasksListAdapter.itemCount == 0
            if (isEmpty) {
                // Show empty text
                binding.emptyData.visibility = View.VISIBLE
                binding.rvTasks.visibility = View.GONE
            } else {
                // Show RecyclerView
                binding.emptyData.visibility = View.GONE
                binding.rvTasks.visibility = View.VISIBLE
            }

            val isLoading = loadState.refresh is LoadState.Loading
            if (isLoading) {
                binding.loader.visibility = View.VISIBLE
                binding.loader.startAnimation(
                    AnimationUtils.loadAnimation(
                        requireContext(),
                        R.anim.loader_animation
                    )
                )
            } else {
                binding.loader.clearAnimation()
                binding.loader.visibility = View.GONE
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        shutDown()
    }

    override fun shutDown() {
        //doSomething
    }

    companion object {
        const val TAG = "TasksFragment"
    }

    private fun searchResult(keywords: String) {
        lifecycleScope.launchWhenStarted {
            tasksViewModel.getTasksByKeywords(
                currentStatus,
                keywords,
                "Bearer ${DataStoreManager(requireContext()).getCadreToken()}"
            ).collect(stateCollector)
        }
    }

    private val stateCollector: FlowCollector<NetworkResult<TasksFiltersResponseModel>> =
        FlowCollector { response ->
            when (response) {
                is NetworkResult.Loading -> {
                    binding.loader.visibility = View.VISIBLE
                    binding.loader.startAnimation(
                        AnimationUtils.loadAnimation(
                            requireContext(),
                            R.anim.loader_animation
                        )
                    )
                }

                is NetworkResult.Success -> {
                    binding.loader.clearAnimation()
                    binding.loader.visibility = View.GONE
                    response.data?.message?.data.let {
                        Log.d(TAG, "data $it")
                        if (it.isNullOrEmpty()) {
                            // Show empty text
                            binding.emptyData.visibility = View.VISIBLE
                            binding.rvTasks.visibility = View.GONE
                        } else {
                            // Show RecyclerView
                            taskListAdapter.submitList(it)
                            binding.rvTasks.adapter = null
                            binding.rvTasks.adapter = taskListAdapter
                            binding.emptyData.visibility = View.GONE
                            binding.rvTasks.visibility = View.VISIBLE
                        }
                    }

                }

                is NetworkResult.Error -> {
                    // Handle error
                    Log.e(TAG, "response error ${response.message}")
                    binding.loader.clearAnimation()
                    binding.loader.visibility = View.GONE
                }
            }
        }

}