package com.polstrat.cadre.viewModels

import android.app.Application
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.polstrat.cadre.modelClass.requestModel.FCMRequestModel
import com.polstrat.cadre.modelClass.responseModel.FCMResponseModel
import com.polstrat.cadre.networkClient.NetworkResult
import com.polstrat.cadre.repositories.MainRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MainViewModel(
    application: Application
) : BaseViewModel(application) {

    private var mainRepository: MainRepository =
        MainRepository(application)

    private var selectedItemId = MutableLiveData<Int>()
    val redirectToNotif = MutableLiveData<String>()
    val isNotificationReceived = MutableLiveData<String>()
    val isProfileDeleted = MutableLiveData<Boolean>()

    private val _moveUIState = MutableStateFlow<PolstratUIState>(PolstratUIState.Empty)
    var moveUIState: StateFlow<PolstratUIState> = _moveUIState.asStateFlow()

    fun updateUIState(newState: PolstratUIState) {
        viewModelScope.launch {
            _moveUIState.value = newState
        }
    }

    fun saveSelectedBottomMenuId(selectedItemId: Int) {
        this.selectedItemId.value = selectedItemId
    }


    fun getSelectedBottomMenuId(): Int? {
        return selectedItemId.value
    }

    suspend fun sendToken(
        fcmRequestModel: FCMRequestModel,
        token: String
    ): Flow<NetworkResult<FCMResponseModel>> {
        return mainRepository.sendToken(fcmRequestModel, token)
    }

    sealed class PolstratUIState {
        object Empty : PolstratUIState()
        object HomeScreen : PolstratUIState()
        object MyTasksScreen : PolstratUIState()
        object FormScreen : PolstratUIState()
        object ProfileScreen : PolstratUIState()
    }
}