package com.polstrat.cadre.viewModels

import android.app.Application
import androidx.lifecycle.MutableLiveData
import com.polstrat.cadre.modelClass.responseModel.UserProfileResponseModel
import com.polstrat.cadre.networkClient.NetworkResult
import com.polstrat.cadre.repositories.ProfileRepository
import kotlinx.coroutines.flow.Flow

class ProfileViewModel(application: Application) : BaseViewModel(application) {

    private val profileRepository: ProfileRepository =
        ProfileRepository(application)

    fun releaseViewModel() {
        onCleared()
    }

    var profilePic = MutableLiveData<String>()

    suspend fun getUserById(
        cadreId: String,
        token: String
    ): Flow<NetworkResult<UserProfileResponseModel>> {
        return profileRepository.getUserById(cadreId, token)
    }

}