package com.polstrat.cadre.fragment

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.location.Geocoder
import android.location.Location
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.activityViewModels
import com.google.android.gms.common.api.Status
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.model.Place
import com.google.android.libraries.places.api.net.PlacesClient
import com.google.android.libraries.places.widget.AutocompleteSupportFragment
import com.google.android.libraries.places.widget.listener.PlaceSelectionListener
import com.polstrat.cadre.R
import com.polstrat.cadre.databinding.FragmentRevisedMapBinding
import com.polstrat.cadre.utils.BaseFragment
import com.polstrat.cadre.utils.Constants
import com.polstrat.cadre.utils.Spec
import com.polstrat.cadre.viewModels.FormViewModel
import java.io.IOException


class RevisedMapFragment : BaseFragment(), Spec {
    private var binding: FragmentRevisedMapBinding? = null
    private lateinit var placesClient: PlacesClient
    private lateinit var googleMap: GoogleMap
    private var latitude: Double? = null
    private var longitude: Double? = null
    private var address = ""
    private val formViewModel: FormViewModel by activityViewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            address = it.getString(Constants.ADDRESS, "").toString()
            latitude = it.getString(Constants.LATITUDE)?.toDouble()
            longitude = it.getString(Constants.LONGITUDE)?.toDouble()
        }
        Log.d(TAG, "addr>> $address, $latitude, $longitude")
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_revised_map, container, false)
        return binding!!.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding?.apply {
            presenter = this@RevisedMapFragment
            lifecycleOwner = this@RevisedMapFragment
            executePendingBindings()
        }
        setUpResources()
    }

    companion object {
        const val TAG = "RevisedMapFragment"
        private const val REQUEST_LOCATION_PERMISSION = 1
    }

    override fun setUpResources() {
        setBottomNavVisibility(View.GONE)
        if (!Places.isInitialized()) {
            context?.applicationContext?.let {
                Places.initialize(
                    it,
                    getString(R.string.google_maps_api_key)
                )
            }
        }

        placesClient = Places.createClient(requireContext())

        // Initialize the Google Map
        val mapFragment =
            childFragmentManager.findFragmentById(R.id.mapFragment) as SupportMapFragment
        mapFragment.getMapAsync { gMap ->
            googleMap = gMap
            enableMyLocation()
        }

        // Initialize and configure AutocompleteFragment
        val autocompleteFragment =
            childFragmentManager.findFragmentById(R.id.autocompleteContainer) as AutocompleteSupportFragment?

        autocompleteFragment?.setPlaceFields(
            listOf(
                Place.Field.ID,
                Place.Field.NAME,
                Place.Field.LAT_LNG
            )
        )
        autocompleteFragment?.setHint("Enter building, area or street name")
        autocompleteFragment?.setCountries("IN")


        autocompleteFragment?.setOnPlaceSelectedListener(object : PlaceSelectionListener {
            override fun onPlaceSelected(place: Place) {
                // Handle the selected place
                val placeName = place.name
                val placeId = place.id
                val placeLatLng = place.latLng
                if (placeLatLng != null) {
                    latitude = placeLatLng.latitude
                }
                if (placeLatLng != null) {
                    longitude = placeLatLng.longitude
                }
                if (placeName != null) {
                    address = placeName
                }

                // Add your logic to handle the selected place
                if (placeLatLng != null) {
                    if (placeName != null) {
                        redirectToLocation(placeLatLng, placeName)
                    }
                }

            }

            override fun onError(status: Status) {
                // Handle errors
                Log.e("AutocompleteError", "Error: $status")
            }
        })
        /* if (address.isNotEmpty()) {
             binding?.btnDone?.visibility = View.GONE
             latitude?.let { longitude?.let { it1 -> LatLng(it, it1) } }
                 ?.let { redirectToLocation(it, address) }
         }*/
    }

    fun addrSelected() {
        formViewModel.lat.value = latitude.toString()
        formViewModel.lon.value = longitude.toString()
        formViewModel.addr.value = address
        showToastShort(requireContext(), "Location added")
        goBack()
    }

    private fun redirectToLocation(location: LatLng, placeName: String) {
        // Move the camera to the specified location or add a marker

        googleMap.clear()
        // Add a marker for the selected place
        location.let { CameraUpdateFactory.newLatLngZoom(it, 15f) }
            .let { googleMap.animateCamera(it) }

        // Add a marker at the searched location
        val vectorDrawable = ContextCompat.getDrawable(requireContext(), R.drawable.marker)
        val bitmap = Bitmap.createBitmap(
            vectorDrawable?.intrinsicWidth ?: 0,
            vectorDrawable?.intrinsicHeight ?: 0,
            Bitmap.Config.ARGB_8888
        )
        val canvas = Canvas(bitmap)
        vectorDrawable?.setBounds(0, 0, canvas.width, canvas.height)
        vectorDrawable?.draw(canvas)

        val customMarker = BitmapDescriptorFactory.fromBitmap(bitmap)
        location.let {
            MarkerOptions().position(it).title(placeName).icon(customMarker)
        }
            .let {
                googleMap.addMarker(
                    it
                )
            }
    }

    fun goBack() {
        requireActivity().onBackPressedDispatcher.onBackPressed()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        shutDown()
    }

    override fun shutDown() {
        //doSomething
    }

    private fun enableMyLocation() {
        if (ContextCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION
            )
            == PackageManager.PERMISSION_GRANTED
        ) {
            googleMap.isMyLocationEnabled = true
            // Move camera to user's current location
            val fusedLocationClient =
                LocationServices.getFusedLocationProviderClient(requireContext())
            fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
                location?.let {
                    val currentLatLng = LatLng(it.latitude, it.longitude)
                    val geocoder = Geocoder(requireContext())
                    try {
                        val addresses =
                            geocoder.getFromLocation(it.latitude, it.longitude, 1)
                        if (!addresses.isNullOrEmpty()) {
                            val areaName = addresses[0].featureName
                            val cityName = addresses[0].subLocality
                            val stateName = addresses[0].adminArea
                            val countryName = addresses[0].countryName
                            longitude = it.longitude
                            latitude = it.latitude
                            address = "$areaName, $cityName, $stateName, $countryName"
                            redirectToLocation(currentLatLng, address)
                            Log.d(TAG, "$cityName, $areaName")
                        }
                    } catch (e: IOException) {
                        e.printStackTrace()
                    }

                }
            }
        } else {
            ActivityCompat.requestPermissions(
                requireActivity(),
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                REQUEST_LOCATION_PERMISSION
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        if (requestCode == REQUEST_LOCATION_PERMISSION) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                enableMyLocation()
            }
        }
    }
}