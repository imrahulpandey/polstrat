package com.polstrat.cadre.viewModels

import android.app.Application
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.polstrat.cadre.modelClass.requestModel.StatusRequest
import com.polstrat.cadre.modelClass.responseModel.TasksFiltersResponseModel
import com.polstrat.cadre.modelClass.responseModel.UserTasks
import com.polstrat.cadre.networkClient.NetworkResult
import com.polstrat.cadre.repositories.TasksRepository
import kotlinx.coroutines.flow.Flow

class TasksViewModel(
    application: Application
) : BaseViewModel(application) {

    private val tasksRepository: TasksRepository =
        TasksRepository(application)

    private var userTaskDataList = MutableLiveData<UserTasks>()

    fun getUserTaskData(): MutableLiveData<UserTasks> {
        return userTaskDataList
    }

    fun getAllTasks(token: String, statusRequest: StatusRequest): Flow<PagingData<UserTasks>> {
        return tasksRepository.getAllTasks(token, statusRequest).cachedIn(viewModelScope)
    }

    suspend fun getTasksByKeywords(
        status: String,
        keywords: String,
        token: String
    ): Flow<NetworkResult<TasksFiltersResponseModel>> {
        return tasksRepository.getTasksByKeywords(status, keywords, token)
    }
}