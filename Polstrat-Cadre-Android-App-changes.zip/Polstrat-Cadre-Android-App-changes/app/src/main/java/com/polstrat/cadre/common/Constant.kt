package com.polstrat.cadre.common

class Constant {
    companion object {
        const val UserEmail = "ashok01@polstrat.com"
        const val UserPassword = "cadre@deep"

        //        const val UserEmail = "client@500x.tech"
//        const val UserPassword = "password!"
        var Token =
            "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjp7Il9pZCI6IjY0YmE1OWVkZTM1NWJjNDFlYWY0NThiNSIsImZpcnN0TmFtZSI6InJvaGl0IiwibGFzdE5hbWUiOiJzaGF3Iiwib3JnYW5pc2F0aW9uSWQiOiI2NGJhNTllZGUzNTViYzQxZWFmNDU4YWMiLCJvZmZpY2VJZCI6IjY0YmE1OWVkZTM1NWJjNDFlYWY0NThiMSIsImNvbnN0aXR1ZW5jeUlkIjoiNjRiZmJmMDNjZTNmZGVhMzUzNDQ5ZGU5IiwiZW1haWwiOiJjbGllbnRANTAweC50ZWNoIiwicGhvbmUiOjkyOTE3NDc3MjcsInJvbGUiOiJjbGllbnQiLCJzdWJzY3JpcHRpb24iOiI2NDNkMGJiNzQzNjAzN2UwZGQ0MTBmNTEiLCJ0eXBlIjoiY2xpZW50In0sImlhdCI6MTY5MTEzMDAwOCwiZXhwIjoxNjkxOTk0MDA4fQ.Ht2LfsH5z5Kp83Bn1GpB1_ceW2oDWK0wNKeVpwJ3lh4"
    }
}