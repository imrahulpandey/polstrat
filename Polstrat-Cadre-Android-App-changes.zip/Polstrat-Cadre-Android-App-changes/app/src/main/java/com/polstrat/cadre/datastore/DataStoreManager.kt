package com.move.radianandroid.utils.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.SharedPreferencesMigration
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.io.IOException


private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(
    name = "PolstratDataStore",
    produceMigrations = ::sharedPreferencesMigration
)

private fun sharedPreferencesMigration(context: Context) =
    listOf(SharedPreferencesMigration(context, "MyPreferences"))

class DataStoreManager(context: Context) : DataStoreAPI {

    private val dataSource = context.dataStore

    override suspend fun <T> getPreferenceValue(key: Preferences.Key<T>, defaultValue: T): T =
        dataSource.data.first()[key] ?: defaultValue

    override suspend fun <T> putPreferenceValue(key: Preferences.Key<T>, value: T) {
        dataSource.edit { preferences ->
            preferences[key] = value
        }
    }

    override suspend fun <T> getPreferenceFlow(key: Preferences.Key<T>, defaultValue: T): Flow<T> =
        dataSource.data.catch { exception ->
            if (exception is IOException) {
                emit(emptyPreferences())
            } else {
                throw exception
            }
        }.map { preferences ->
            val result = preferences[key] ?: defaultValue
            result
        }

    override suspend fun <T> removePreference(key: Preferences.Key<T>) {
        dataSource.edit { preferences ->
            preferences.remove(key)
        }
    }

    override suspend fun <T> clearAllPreference() {
        dataSource.edit { preferences ->
            preferences.clear()
        }
    }

    suspend fun saveConstituencyId(value: String) {
        putPreferenceValue(DataStoreConstants.CONSTITUENCY_Id, value)
    }

    suspend fun getConstituencyId(): String {
        return getPreferenceValue(DataStoreConstants.CONSTITUENCY_Id, "")
    }


    suspend fun saveClientId(value: String) {
        putPreferenceValue(DataStoreConstants.CLIENT_ID, value)
    }

    suspend fun getClientId(): String {
        return getPreferenceValue(DataStoreConstants.CLIENT_ID, "")
    }

    suspend fun saveEmail(value: String) {
        putPreferenceValue(DataStoreConstants.EMAIL, value)
    }

    suspend fun getEmail(): String {
        return getPreferenceValue(DataStoreConstants.EMAIL, "")
    }


    suspend fun saveCadreToken(value: String) {
        putPreferenceValue(DataStoreConstants.CADRE_TOKEN, value)
    }

    suspend fun getCadreToken(): String {
        return getPreferenceValue(DataStoreConstants.CADRE_TOKEN, "")
    }

    suspend fun saveFCMToken(value: String) {
        putPreferenceValue(DataStoreConstants.FCM_TOKEN, value)
    }

    suspend fun getFCMToken(): String {
        return getPreferenceValue(DataStoreConstants.FCM_TOKEN, "")
    }

    suspend fun saveToken(value: String) {
        putPreferenceValue(DataStoreConstants.TOKEN, value)
    }

    suspend fun getToken(): String {
        return getPreferenceValue(DataStoreConstants.TOKEN, "")
    }

    suspend fun saveProfilePic(value: String) {
        putPreferenceValue(DataStoreConstants.PROFILE_PIC, value)
    }

    suspend fun getProfilePic(): String {
        return getPreferenceValue(DataStoreConstants.PROFILE_PIC, "")
    }

    suspend fun saveFName(value: String) {
        putPreferenceValue(DataStoreConstants.F_NAME, value)
    }

    suspend fun getFName(): String {
        return getPreferenceValue(DataStoreConstants.F_NAME, "")
    }

    suspend fun saveLName(value: String) {
        putPreferenceValue(DataStoreConstants.L_NAME, value)
    }

    suspend fun getLName(): String {
        return getPreferenceValue(DataStoreConstants.L_NAME, "")
    }

    suspend fun saveRole(value: String) {
        putPreferenceValue(DataStoreConstants.ROLE, value)
    }

    suspend fun getRole(): String {
        return getPreferenceValue(DataStoreConstants.ROLE, "")
    }

    suspend fun saveNotificationReceived(value: String) {
        putPreferenceValue(DataStoreConstants.NOTIFICATION_RECEIVED, value)
    }

    suspend fun getNotificationReceived(): String {
        return getPreferenceValue(DataStoreConstants.NOTIFICATION_RECEIVED, "")
    }
}