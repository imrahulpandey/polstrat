package com.polstrat.cadre.modelClass.responseModel

import com.google.gson.annotations.SerializedName
import com.polstrat.cadre.modelClass.requestModel.UploadImage

data class TasksFiltersResponseModel(
    val error: String? = null,
    val message: Message? = null,
    val status: Boolean? = false
)

data class Message(
    val currentpage: Int? = null,
    val data: ArrayList<UserTasks>? = null,
    val error: String? = null,
    val message: String? = null,
    val status: Boolean? = false,
    val totalTask: Int? = null,
    val totalpages: Int? = null
)


data class UserTasks(
    @SerializedName("__v")
    val v: Int? = null,
    @SerializedName("_id")
    val id: String? = null,
    val assignedToUserId: String? = null,
    val assignedToUserName: String? = null,
    val categoryId: String? = null,
    val categoryName: String? = null,
    val clientId: String? = null,
    val createdAt: String? = null,
    val createdByUserId: String? = null,
    val createdByUserName: String? = null,
    val createdByUserRole: String? = null,
    val description: String? = null,
    val dueDate: String? = null,
    val grievanceId: String? = null,
    val location: Location? = null,
    val officeId: String? = null,
    val officeName: String? = null,
    val postCompletionImages: List<UploadImage>? = null,
    val priority: String? = null,
    val profilePicture: ProfilePicture? = null,
    val status: String? = null,
    val subCategoryId: String? = null,
    val subCategoryName: String? = null,
    val title: String? = null,
    val updatedAt: String? = null,
    val uploadImages: List<UploadImage>? = null
)

data class Location(
    val address: String? = null,
    val lat: String? = null,
    val lng: String? = null
)

data class ProfilePicture(
    val key: String? = null,
    val name: String? = null,
    val publicUrl: String? = null
)