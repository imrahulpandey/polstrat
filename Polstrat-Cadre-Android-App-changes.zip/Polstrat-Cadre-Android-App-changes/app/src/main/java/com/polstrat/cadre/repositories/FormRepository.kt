package com.polstrat.cadre.repositories

import android.app.Application
import com.polstrat.cadre.modelClass.Categories
import com.polstrat.cadre.modelClass.requestModel.FormRequestModel
import com.polstrat.cadre.modelClass.requestModel.IssueReportRequest
import com.polstrat.cadre.modelClass.responseModel.FormResponseModel
import com.polstrat.cadre.modelClass.responseModel.ReportedIssueModelResponse
import com.polstrat.cadre.networkClient.NetworkResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn

class FormRepository(application: Application) : BaseRepository(application) {

    suspend fun createForm(
        formRequestModel: FormRequestModel,
        token: String
    ): Flow<NetworkResult<FormResponseModel>> {
        return flow {
            try {
                emit(NetworkResult.Loading())
                val response = retrofitInterface.createForm(formRequestModel, token)
                if (response.isSuccessful && response.body() != null) {
                    emit(NetworkResult.Success(response.body()))
                } else {
                    emit(NetworkResult.Error(response.message()))
                }
            } catch (e: Exception) {
                emit(NetworkResult.Error(e.message.toString()))
            }
        }.flowOn(Dispatchers.IO)

    }

    suspend fun getCategories(
        token: String
    ): Flow<NetworkResult<Categories>> {
        return flow {
            try {
                emit(NetworkResult.Loading())
                val response = retrofitInterface.getCategories(10, 1, "DES", token)
                if (response.isSuccessful && response.body() != null) {
                    emit(NetworkResult.Success(response.body()))
                } else {
                    emit(NetworkResult.Error(response.message()))
                }
            } catch (e: Exception) {
                emit(NetworkResult.Error(e.message.toString()))
            }
        }.flowOn(Dispatchers.IO)

    }

    suspend fun getSubCategories(
        parentId: String,
        token: String
    ): Flow<NetworkResult<Categories>> {
        return flow {
            try {
                emit(NetworkResult.Loading())
                val response = retrofitInterface.getSubCategories(100, 1, "DESC", parentId, token)
                if (response.isSuccessful && response.body() != null) {
                    emit(NetworkResult.Success(response.body()))
                } else {
                    emit(NetworkResult.Error(response.message()))
                }
            } catch (e: Exception) {
                emit(NetworkResult.Error(e.message.toString()))
            }
        }.flowOn(Dispatchers.IO)

    }

    suspend fun raiseTickets(
        issueReportRequest: IssueReportRequest,
        token: String
    ): Flow<NetworkResult<ReportedIssueModelResponse>> {
        return flow {
            try {
                emit(NetworkResult.Loading())
                val response = retrofitInterface.raiseTickets(issueReportRequest, token)
                if (response.isSuccessful && response.body() != null) {
                    emit(NetworkResult.Success(response.body()))
                } else {
                    emit(NetworkResult.Error(response.message()))
                }
            } catch (e: Exception) {
                emit(NetworkResult.Error(e.message.toString()))
            }
        }.flowOn(Dispatchers.IO)

    }

}