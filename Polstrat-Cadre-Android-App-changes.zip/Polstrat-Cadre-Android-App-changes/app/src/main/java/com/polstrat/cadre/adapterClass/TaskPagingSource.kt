package com.polstrat.cadre.adapterClass

import android.util.Log
import androidx.paging.PagingSource
import androidx.paging.PagingState
import com.polstrat.cadre.modelClass.requestModel.StatusRequest
import com.polstrat.cadre.modelClass.responseModel.UserTasks
import com.polstrat.cadre.networkClient.APIInterface

class TaskPagingSource(
    private val apiInterface: APIInterface,
    val token: String,
    private val statusRequest: StatusRequest
) : PagingSource<Int, UserTasks>() {

    companion object {
        const val STARTING_PAGE_INDEX = 1
    }

    override fun getRefreshKey(state: PagingState<Int, UserTasks>): Int? {
        return state.anchorPosition?.let { anchorPosition ->
            state.closestPageToPosition(anchorPosition)?.prevKey?.plus(1)
                ?: state.closestPageToPosition(anchorPosition)?.nextKey?.minus(1)
        }
    }

    override suspend fun load(params: LoadParams<Int>): LoadResult<Int, UserTasks> {
        val pageIndex = params.key ?: STARTING_PAGE_INDEX
        return try {
            val response = apiInterface.getTasks(
                pageIndex,
                10,
                "DES",
                token,
                statusRequest
            )
            val userData = response.body()?.message?.data

            Log.d("TAG", "userDataList>> $userData")
            LoadResult.Page(
                data = userData ?: listOf(),
                prevKey = if (pageIndex == STARTING_PAGE_INDEX) null else pageIndex - 1,
                nextKey = if (userData?.isEmpty() == true) null else pageIndex + 1
            )
        } catch (exception: Exception) {
            return LoadResult.Error(exception)
        }
    }
}