package com.polstrat.cadre.modelClass.responseModel

import com.google.gson.annotations.SerializedName

data class ReportedIssueModelResponse(
    val data: IssueData,
    val error: Any,
    val message: String,
    val status: Boolean
)

data class IssueData(
    @SerializedName("__v")
    val v: Int,
    @SerializedName("_id")
    val id: String,
    val category: String,
    val clientId: String,
    val comment: String,
    val companyName: String,
    val createdAt: String,
    val date: String,
    val email: String,
    val issueName: String,
    val loggedBy: String,
    val phone: Long,
    val ticketStatus: String,
    val updatedAt: String
)