package com.polstrat.cadre.adapterClass

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.polstrat.cadre.modelClass.responseModel.ViewPagerModel
import com.polstrat.cadre.R

class ViewPagerAdapterClass(var list: ArrayList<ViewPagerModel>) :
    RecyclerView.Adapter<ViewPagerAdapterClass.ViewHolder>() {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val illustrator: ImageView = itemView.findViewById(R.id.Illustrator)
        val title: TextView = itemView.findViewById(R.id.Title)
        val description: TextView = itemView.findViewById(R.id.Description)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view: View =
            LayoutInflater.from(parent.context).inflate(R.layout.custom_viewpager, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val viewPagerModel: ViewPagerModel = list[position]
        holder.illustrator.setImageResource(viewPagerModel.illustrator)
        holder.title.text = viewPagerModel.title
        holder.description.text = viewPagerModel.description
    }
}