package com.polstrat.cadre.authentication

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.polstrat.cadre.common.Constant
import com.polstrat.cadre.fragment.HostActivity
import com.polstrat.cadre.networkClient.APIInterface
import com.polstrat.cadre.networkClient.ServiceBuilder
import com.polstrat.cadre.R
import com.polstrat.cadre.sharedPrefs.SharedPrefs
import com.polstrat.cadre.databinding.ActivityLoginWithEmailBinding
import org.json.JSONException
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class LoginWithEmail : AppCompatActivity() {

    lateinit var binding: ActivityLoginWithEmailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_login_with_email)

        val sharedPref = SharedPrefs(this)

      /*  val retrofit = ServiceBuilder.buildService(APIInterface::class.java)
        val requestObj = LoginRequestModel(Constant.UserEmail, Constant.UserPassword)

        retrofit.getLogin(requestObj).enqueue(
            object : Callback<LoginResponseModel> {
                override fun onResponse(
                    call: Call<LoginResponseModel>,
                    response: Response<LoginResponseModel>
                ) {
                    if (!response.isSuccessful) {

                        sharedPref.saveString(
                            "FirstName",
                            response.body()?.data?.clientUser?.firstName.toString()
                        )
                        sharedPref.saveString(
                            "Role",
                            response.body()?.data?.clientUser?.role.toString()
                        )
                        sharedPref.saveString(
                            "UserId",
                            response.body()?.data?.clientUser?.id.toString()
                        )
                        Constant.Token = response.body()?.data?.token.toString()

                        val intent = Intent(this@LoginWithEmail, HostActivity::class.java)
                        startActivity(intent)
                        finish()

                    } else {
                        val errorResponse = response.errorBody()?.string()
                        val errorMessage = try {
                            val jsonObject = JSONObject(errorResponse.toString())
                            jsonObject.getString("message")
                        } catch (e: JSONException) {
                            "Unknown error occurred."
                        }
                        Toast.makeText(this@LoginWithEmail, errorMessage, Toast.LENGTH_LONG).show()
                    }
                }

                override fun onFailure(call: Call<LoginResponseModel>, t: Throwable) {
                    Toast.makeText(this@LoginWithEmail, t.localizedMessage, Toast.LENGTH_LONG)
                        .show()
                }
            }
        )*/
    }
}