package com.polstrat.cadre.modelClass.requestModel

import okhttp3.RequestBody

data class FormRequestModel(
    val grievanceTitle: String = "No Title",
    val categoryId: String,
    val categoryName: String,
    val constituencyId: String,
    val description: String,
    val firstName: String,
    val gender: String,
    val lastName: String,
    val location: Location,
    val numberOfPeople: String,
    val email: String,
    val phone: String,
    val priority: String,
    val subCategoryId: String,
    val subCategoryName: String,
    val uploadImages: List<UploadImage>,
    val visitorType: String
)

data class Location(
    val address: String,
    val lat: String,
    val lng: String
)

data class UploadImage(
    val guid: String,
    val key: String,
    val name: String,
    val publicUrl: String
)

data class SendImage(
    val grievanceImages: RequestBody
)