package com.polstrat.cadre.authentication

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.polstrat.cadre.fragment.HostActivity
import com.polstrat.cadre.R
import com.polstrat.cadre.databinding.ActivityVerificationSuccessfulBinding

class VerificationSuccessful : AppCompatActivity() {

    private lateinit var binding: ActivityVerificationSuccessfulBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_verification_successful)

        val handler = Handler()
        handler.postDelayed({
            val intent = Intent(this, HostActivity::class.java)
            startActivity(intent)
            finish()
        }, 2500)

    }
}