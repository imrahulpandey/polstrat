package com.polstrat.cadre.forms

import android.os.Bundle
import android.os.Handler
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.polstrat.cadre.R
import com.polstrat.cadre.databinding.ActivityFormSubmittedSuccessfulBinding

class FormSubmittedSuccessful : AppCompatActivity() {

    lateinit var binding: ActivityFormSubmittedSuccessfulBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_form_submitted_successful)
        setContentView(binding.root)

        val handler = Handler()
        handler.postDelayed({
            finish()
        }, 3000)

    }
}