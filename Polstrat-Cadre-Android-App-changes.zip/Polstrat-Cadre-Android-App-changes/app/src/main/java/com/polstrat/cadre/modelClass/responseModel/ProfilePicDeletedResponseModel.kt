package com.polstrat.cadre.modelClass.responseModel

import com.google.gson.annotations.SerializedName

data class ProfilePicDeletedResponseModel(
    val data: UpdatedRecords,
    val error: Any,
    val message: String,
    val status: Boolean
)

data class UpdatedRecords(
    @SerializedName("__v")
    val v: Int,
    @SerializedName("_id")
    val id: String,
    val clientPassword: String,
    val constituencyId: String,
    val createdAt: String,
    val email: String,
    val firstName: String,
    val lastName: String,
    val lastpasswordchangedate: String,
    val officeId: String,
    val organisationId: String,
    val otpObject: OtpObject,
    val password: String,
    val phone: Long,
    val planDuration: String,
    val profileImageLink: ProfileImageLink,
    val reportsTo: String,
    val resetPasswordToken: Any,
    val role: String,
    val status: String,
    val subscription: List<Subscription>,
    val updatedAt: String,
    val validityEnd: String,
    val validityStart: String
)

data class OtpObject(
    val createdAt: String,
    val otp: String
)