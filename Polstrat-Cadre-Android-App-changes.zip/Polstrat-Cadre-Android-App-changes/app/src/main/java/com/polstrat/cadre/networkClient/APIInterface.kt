package com.polstrat.cadre.networkClient

import com.polstrat.cadre.modelClass.Categories
import com.polstrat.cadre.modelClass.requestModel.FCMRequestModel
import com.polstrat.cadre.modelClass.requestModel.FormRequestModel
import com.polstrat.cadre.modelClass.requestModel.IssueReportRequest
import com.polstrat.cadre.modelClass.requestModel.StatusRequest
import com.polstrat.cadre.modelClass.requestModel.UpdateStatusRequest
import com.polstrat.cadre.modelClass.requestModel.VerifyOtpRequest
import com.polstrat.cadre.modelClass.responseModel.FCMResponseModel
import com.polstrat.cadre.modelClass.responseModel.FormResponseModel
import com.polstrat.cadre.modelClass.responseModel.GetImageData
import com.polstrat.cadre.modelClass.responseModel.NotificationMarkedReadResponse
import com.polstrat.cadre.modelClass.responseModel.NotificationResponseModel
import com.polstrat.cadre.modelClass.responseModel.ProfilePicDeletedResponseModel
import com.polstrat.cadre.modelClass.responseModel.ProfilePicResponseModel
import com.polstrat.cadre.modelClass.responseModel.ReportedIssueModelResponse
import com.polstrat.cadre.modelClass.responseModel.TaskResponseModel
import com.polstrat.cadre.modelClass.responseModel.TaskUpdatedResponseModel
import com.polstrat.cadre.modelClass.responseModel.TasksFiltersResponseModel
import com.polstrat.cadre.modelClass.responseModel.UniversalResponse
import com.polstrat.cadre.modelClass.responseModel.UserProfileResponseModel
import okhttp3.MultipartBody
import retrofit2.Call
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Headers
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Part
import retrofit2.http.Path
import retrofit2.http.Query

interface APIInterface {
    @Headers("Content-Type: application/json")
    @GET("cadres/sendOTP")
    suspend fun sendOTP(@Query("phone") phone: String): Response<UniversalResponse>

    @Headers("Content-Type: application/json")
    @POST("cadres/cadresLogin")
    suspend fun verifyOTP(@Body verifyOtpRequest: VerifyOtpRequest): Response<UniversalResponse>

    @Headers("Content-Type: application/json")
    @GET("task/getTasksStatusSummary")
    suspend fun getHomeGraphData(@Header("Authorization") Token: String): Response<TaskResponseModel>

    @Headers("Content-Type: application/json")
    @GET("task/getPrioritiesOfTask")
    suspend fun getHomePriorityData(@Header("Authorization") Token: String): Response<TaskResponseModel>

    @Headers("Content-Type: application/json")
    @POST("task/filterTask/")
    suspend fun getTasks(
        @Query("page") page: Int,
        @Query("limit") limit: Int,
        @Query("sort") sort: String,
        @Header("Authorization") Token: String,
        @Body statusRequest: StatusRequest
    ): Response<TasksFiltersResponseModel>

    @Headers("Content-Type: application/json")
    @PUT("task/updateTaskStatus/{taskId}")
    fun updateTask(
        @Path("taskId") taskId: String,
        @Header("Authorization") Token: String,
        @Body statusRequest: UpdateStatusRequest
    ): Call<TaskUpdatedResponseModel>

    @Headers("Content-Type: application/json")
    @GET("clients/clientUser/{id}")
    suspend fun getUserById(
        @Path("id") id: String,
        @Header("Authorization") Token: String
    ): Response<UserProfileResponseModel>

    @Headers("Content-Type: application/json")
    @GET("category/main")
    suspend fun getCategories(
        @Query("size") size: Int,
        @Query("page") page: Int,
        @Query("sort") sort: String,
        @Header("Authorization") Token: String
    ): Response<Categories?>

    @Headers("Content-Type: application/json")
    @GET("category/sub")
    suspend fun getSubCategories(
        @Query("size") size: Int,
        @Query("page") page: Int,
        @Query("sort") sort: String,
        @Query("parentId") parentId: String,
        @Header("Authorization") Token: String
    ): Response<Categories?>

    @Multipart
    @POST("grievances/uploadGrievanceImages")
    fun uploadImages(
        @Part grievanceImages: List<MultipartBody.Part>,
        @Header("Authorization") Token: String
    ): Call<GetImageData>

    @Multipart
    @PUT("clients/info/profile/{id}")
    fun updateProfilePic(
        @Path("id") id: String,
        @Part profileImageLink: List<MultipartBody.Part>,
        @Header("Authorization") Token: String
    ): Call<ProfilePicResponseModel>

    @Headers("Content-Type: application/json")
    @POST("grievances/createGrievance")
    suspend fun createForm(
        @Body formRequestModel: FormRequestModel,
        @Header("Authorization") Token: String
    ): Response<FormResponseModel>

    @Headers("Content-Type: application/json")
    @POST("tickets")
    suspend fun raiseTickets(
        @Body issueReportRequest: IssueReportRequest,
        @Header("Authorization") Token: String
    ): Response<ReportedIssueModelResponse>

    @Headers("Content-Type: application/json")
    @GET("notification")
    suspend fun getNotifications(
        @Query("page") page: Int,
        @Query("limit") limit: Int,
        @Header("Authorization") Token: String
    ): Response<NotificationResponseModel>

    @Headers("Content-Type: application/json")
    @POST("notification/markAsReadAll")
    suspend fun markAsReadAll(
        @Header("Authorization") Token: String
    ): Response<NotificationMarkedReadResponse>

    @Headers("Content-Type: application/json")
    @POST("fcm/storeToken")
    suspend fun sendFCMToken(
        @Body fcmRequestModel: FCMRequestModel,
        @Header("Authorization") Token: String
    ): Response<FCMResponseModel>

    @Headers("Content-Type: application/json")
    @PUT("clients/info/deleteProfileImage/{id}")
    fun deleteProfilePic(
        @Path("id") id: String,
        @Header("Authorization") Token: String
    ): Call<ProfilePicDeletedResponseModel>

    @Headers("Content-Type: application/json")
    @GET("task/searchTaskByStatusAndKeyword")
    suspend fun getFilteredTasksByKeywords(
        @Query("status") status: String,
        @Query("keyword") keyword: String,
        @Header("Authorization") Token: String
    ): Response<TasksFiltersResponseModel>
}