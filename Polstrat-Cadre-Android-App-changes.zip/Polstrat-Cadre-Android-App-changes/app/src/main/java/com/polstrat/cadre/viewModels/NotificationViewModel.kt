package com.polstrat.cadre.viewModels

import android.app.Application
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.polstrat.cadre.modelClass.requestModel.IssueReportRequest
import com.polstrat.cadre.modelClass.requestModel.StatusRequest
import com.polstrat.cadre.modelClass.responseModel.NotificationList
import com.polstrat.cadre.modelClass.responseModel.NotificationMarkedReadResponse
import com.polstrat.cadre.modelClass.responseModel.ReportedIssueModelResponse
import com.polstrat.cadre.modelClass.responseModel.UserTasks
import com.polstrat.cadre.networkClient.NetworkResult
import com.polstrat.cadre.repositories.NotificationRepository
import kotlinx.coroutines.flow.Flow

class NotificationViewModel(
    application: Application
) : BaseViewModel(application) {

    private val notificationRepository: NotificationRepository =
        NotificationRepository(application)

    fun getNotificationsList(token: String): Flow<PagingData<NotificationList>> {
        return notificationRepository.getNotificationsList(token).cachedIn(viewModelScope)
    }

    suspend fun markAsReadAll(
        token: String
    ): Flow<NetworkResult<NotificationMarkedReadResponse>> {
        return notificationRepository.markAsReadAll(token)
    }
}