package com.polstrat.cadre.modelClass.requestModel

data class IssueReportRequest(
    val category: String,
    val comment: String,
    val date: String,
    val email: String,
    val issueName: String,
    val loggedBy: String,
    val phone: Long
)