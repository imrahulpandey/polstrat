package com.polstrat.cadre.adapterClass

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.databinding.DataBindingUtil
import androidx.paging.LoadState
import androidx.paging.LoadStateAdapter
import androidx.recyclerview.widget.RecyclerView
import com.polstrat.cadre.R
import com.polstrat.cadre.databinding.PaginationLoaderBinding

class PaginationLoaderAdapter : LoadStateAdapter<PaginationLoaderAdapter.LoaderViewHolder>() {

    class LoaderViewHolder(val binding: PaginationLoaderBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(loadState: LoadState) {
            binding.loader.isVisible = loadState is LoadState.Loading
        }
    }

    override fun onBindViewHolder(holder: LoaderViewHolder, loadState: LoadState) {
        holder.bind(loadState)
    }

    override fun onCreateViewHolder(parent: ViewGroup, loadState: LoadState): LoaderViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding: PaginationLoaderBinding =
            DataBindingUtil.inflate(inflater, R.layout.pagination_loader, parent, false)
        return LoaderViewHolder(binding)
    }
}